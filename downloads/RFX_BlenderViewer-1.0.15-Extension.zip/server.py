# SPDX-License-Identifier: GPL-3.0-or-later
"""
Hand-rolled RFC 6455 WebSocket server for Blender Viewer.

Stdlib only. The server runs on a background thread; NOTHING in this module
touches bpy directly. Incoming messages are marshaled to Blender's main
thread through `main_thread_queue` + a bpy.app.timers pump that lives in
__init__.py. Outgoing sends are thread-safe and may be called from any
thread.
"""

import base64
import hashlib
import json
import queue
import socket
import struct
import threading

WS_MAGIC = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"
MAX_CLIENT_MESSAGE_BYTES = 1024 * 1024
MAX_PENDING_MAIN_THREAD_TASKS = 256
MAX_PENDING_TASKS_PER_CLIENT = 8

OP_CONT = 0x0
OP_TEXT = 0x1
OP_BINARY = 0x2
OP_CLOSE = 0x8
OP_PING = 0x9
OP_PONG = 0xA

# Callables queued by socket threads, drained on Blender's main thread.
main_thread_queue = queue.Queue(maxsize=MAX_PENDING_MAIN_THREAD_TASKS)


def enqueue_main_thread(fn):
    """Bound socket-to-bpy work so network floods cannot exhaust memory."""
    try:
        main_thread_queue.put_nowait(fn)
        return True
    except queue.Full:
        return False


def get_local_ip():
    """Best-effort LAN IP (no traffic is actually sent)."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        return s.getsockname()[0]
    except OSError:
        return "127.0.0.1"
    finally:
        s.close()


class ClientConnection:
    """One connected phone. Owns its socket; sends are serialized by a lock."""

    def __init__(self, sock, addr, server):
        self.sock = sock
        self.addr = addr
        self.server = server
        self.alive = True
        # Texture hashes already delivered to this client. Kept per-client so
        # reconnecting phones receive the cache contents they need while a
        # long-lived client never receives unchanged images twice.
        self.sent_texture_ids = set()
        self.supports_binary_geometry = False
        self._send_lock = threading.Lock()
        self._pending_lock = threading.Lock()
        self._pending_tasks = 0
        self.thread = threading.Thread(
            target=self._run, name=f"bv-client-{addr[0]}", daemon=True
        )

    # -- lifecycle -----------------------------------------------------

    def start(self):
        self.thread.start()

    def close(self):
        if not self.alive:
            return
        self.alive = False
        try:
            self.sock.shutdown(socket.SHUT_RDWR)
        except OSError:
            pass
        try:
            self.sock.close()
        except OSError:
            pass
        self.server._client_gone(self)

    # -- receive path ---------------------------------------------------

    def _run(self):
        try:
            if not self._handshake():
                return
            self.server._client_ready(self)
            self._recv_loop()
        except (OSError, ConnectionError):
            pass
        finally:
            self.close()

    def _handshake(self):
        self.sock.settimeout(10.0)
        data = b""
        while b"\r\n\r\n" not in data:
            chunk = self.sock.recv(4096)
            if not chunk:
                return False
            data += chunk
            if len(data) > 65536:
                return False
        headers = {}
        lines = data.split(b"\r\n")
        for line in lines[1:]:
            if b":" in line:
                k, v = line.split(b":", 1)
                headers[k.strip().lower().decode()] = v.strip().decode()
        key = headers.get("sec-websocket-key")
        if not key or "websocket" not in headers.get("upgrade", "").lower():
            self.sock.sendall(b"HTTP/1.1 400 Bad Request\r\n\r\n")
            return False
        accept = base64.b64encode(
            hashlib.sha1((key + WS_MAGIC).encode()).digest()
        ).decode()
        resp = (
            "HTTP/1.1 101 Switching Protocols\r\n"
            "Upgrade: websocket\r\n"
            "Connection: Upgrade\r\n"
            f"Sec-WebSocket-Accept: {accept}\r\n\r\n"
        )
        self.sock.sendall(resp.encode())
        self.sock.settimeout(None)
        return True

    def _read_exact(self, n):
        buf = b""
        while len(buf) < n:
            chunk = self.sock.recv(n - len(buf))
            if not chunk:
                raise ConnectionError("socket closed")
            buf += chunk
        return buf

    def _recv_loop(self):
        fragments = []
        frag_opcode = None
        fragmented_bytes = 0
        while self.alive:
            b1, b2 = self._read_exact(2)
            fin = b1 & 0x80
            opcode = b1 & 0x0F
            masked = b2 & 0x80
            length = b2 & 0x7F
            if length == 126:
                length = struct.unpack(">H", self._read_exact(2))[0]
            elif length == 127:
                length = struct.unpack(">Q", self._read_exact(8))[0]
            if length > MAX_CLIENT_MESSAGE_BYTES:
                raise ConnectionError("frame too large")
            # RFC 6455 requires every client-to-server frame to be masked.
            # Rejecting unmasked frames also prevents ambiguous intermediary
            # traffic from being interpreted as a phone command.
            if not masked:
                raise ConnectionError("unmasked client frame")
            mask = self._read_exact(4)
            payload = self._read_exact(length) if length else b""
            if mask:
                payload = bytes(
                    payload[i] ^ mask[i % 4] for i in range(len(payload))
                )

            if opcode == OP_PING:
                self._send_frame(OP_PONG, payload)
                continue
            if opcode == OP_PONG:
                continue
            if opcode == OP_CLOSE:
                self._send_frame(OP_CLOSE, payload[:2])
                return

            if opcode in (OP_TEXT, OP_BINARY):
                if fin:
                    self._deliver(opcode, payload)
                else:
                    fragments = [payload]
                    frag_opcode = opcode
                    fragmented_bytes = len(payload)
            elif opcode == OP_CONT and frag_opcode is not None:
                fragmented_bytes += len(payload)
                if fragmented_bytes > MAX_CLIENT_MESSAGE_BYTES:
                    raise ConnectionError("fragmented message too large")
                fragments.append(payload)
                if fin:
                    self._deliver(frag_opcode, b"".join(fragments))
                    fragments = []
                    frag_opcode = None
                    fragmented_bytes = 0

    def _deliver(self, opcode, payload):
        if opcode != OP_TEXT:
            return  # phone→Blender is JSON text only (protocol 1)
        try:
            message = json.loads(payload.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            self.send_json({"type": "error", "message": "malformed JSON"})
            return
        if not isinstance(message, dict):
            self.send_json({"type": "error", "message": "JSON object required"})
            return
        handler = self.server.on_message
        if handler:
            # Marshal to main thread — bpy access forbidden here.
            with self._pending_lock:
                if self._pending_tasks >= MAX_PENDING_TASKS_PER_CLIENT:
                    self.send_json({
                        "type": "error",
                        "code": "busy",
                        "message": "Too many pending commands; try again shortly",
                    })
                    return
                self._pending_tasks += 1

            def run_handler():
                try:
                    handler(self, message)
                finally:
                    with self._pending_lock:
                        self._pending_tasks = max(0, self._pending_tasks - 1)

            if not enqueue_main_thread(run_handler):
                with self._pending_lock:
                    self._pending_tasks = max(0, self._pending_tasks - 1)
                self.send_json({
                    "type": "error", "code": "busy",
                    "message": "Blender command queue is full",
                })

    # -- send path -------------------------------------------------------

    def _send_frame(self, opcode, payload):
        header = bytes([0x80 | opcode])
        n = len(payload)
        if n < 126:
            header += bytes([n])
        elif n < 65536:
            header += bytes([126]) + struct.pack(">H", n)
        else:
            header += bytes([127]) + struct.pack(">Q", n)
        with self._send_lock:
            self.sock.sendall(header + payload)

    def send_json(self, obj):
        return self.send_json_bytes(json.dumps(
            obj, separators=(",", ":")
        ).encode("utf-8"))

    def send_json_bytes(self, payload):
        """Send an already encoded JSON object (used by snapshot cache)."""
        if not self.alive:
            return False
        try:
            self._send_frame(OP_TEXT, payload)
            return True
        except (OSError, ConnectionError):
            self.close()
            return False

    def send_binary(self, data):
        if not self.alive:
            return False
        try:
            self._send_frame(OP_BINARY, data)
            return True
        except (OSError, ConnectionError):
            self.close()
            return False


class ViewerServer:
    """Accept loop + client registry. Create, then .start()."""

    def __init__(self, port=9010):
        self.port = port
        self.ip = get_local_ip()
        self.clients = []
        self._clients_lock = threading.Lock()
        self._listen_sock = None
        self._accept_thread = None
        self.running = False
        # Set by commands.py on the main thread before start():
        self.on_message = None      # fn(client, dict) — runs on MAIN thread
        self.on_client_ready = None # fn(client) — runs on MAIN thread
        self.on_clients_changed = None  # fn(count) — runs on MAIN thread

    # -- lifecycle -----------------------------------------------------

    def start(self):
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind(("0.0.0.0", self.port))
        sock.listen(4)
        self._listen_sock = sock
        self.running = True
        self.ip = get_local_ip()
        self._accept_thread = threading.Thread(
            target=self._accept_loop, name="bv-accept", daemon=True
        )
        self._accept_thread.start()

    def stop(self):
        self.running = False
        if self._listen_sock:
            try:
                self._listen_sock.close()
            except OSError:
                pass
            self._listen_sock = None
        with self._clients_lock:
            clients = list(self.clients)
        for c in clients:
            c.close()

    def _accept_loop(self):
        while self.running:
            try:
                sock, addr = self._listen_sock.accept()
            except OSError:
                return  # listen socket closed → shutting down
            sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            client = ClientConnection(sock, addr, self)
            client.start()

    # -- client registry callbacks (socket threads) ----------------------

    def _client_ready(self, client):
        # A connection is not broadcast-safe until the HTTP Upgrade has
        # completed. Registering at accept() allowed an unrelated broadcast
        # to put a WebSocket frame in front of the pending HTTP 101 response.
        with self._clients_lock:
            if client not in self.clients:
                self.clients.append(client)
        if self.on_client_ready:
            enqueue_main_thread(lambda: self.on_client_ready(client))
        self._notify_count()

    def _client_gone(self, client):
        with self._clients_lock:
            if client in self.clients:
                self.clients.remove(client)
        self._notify_count()

    def _notify_count(self):
        if self.on_clients_changed:
            n = self.client_count()
            enqueue_main_thread(lambda: self.on_clients_changed(n))

    # -- broadcast (any thread) ------------------------------------------

    def client_count(self):
        with self._clients_lock:
            return len(self.clients)

    def broadcast_json(self, obj):
        payload = json.dumps(obj, separators=(",", ":"))
        with self._clients_lock:
            clients = list(self.clients)
        for c in clients:
            try:
                c._send_frame(OP_TEXT, payload.encode("utf-8"))
            except (OSError, ConnectionError):
                c.close()

    def broadcast_binary(self, data):
        with self._clients_lock:
            clients = list(self.clients)
        for c in clients:
            c.send_binary(data)
