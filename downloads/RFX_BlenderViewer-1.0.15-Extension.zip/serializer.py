# SPDX-License-Identifier: GPL-3.0-or-later
"""
Scene → protocol payloads. MAIN THREAD ONLY (touches bpy everywhere).

Protocol 1 geometry is JSON flat arrays (Maya Viewer parity); the message
shape is kept flat so a binary fast path can replace the arrays in v1.1.

Coordinate system: Blender is Z-up right-handed, SceneKit/RealityKit are
Y-up right-handed. ALL positions/normals/transforms are converted HERE,
before sending: (x, y, z) → (x, z, -y). The iOS side is conversion-free.
"""

import base64
import hashlib
import json
import math
import os
import struct
import tempfile
from collections import OrderedDict

import bpy
import numpy as np
from mathutils import Matrix

PROTOCOL_VERSION = 1

# Change of basis Z-up → Y-up. Proper rotation (det = +1), so converted
# matrices still decompose into clean loc/quat/scale.
_C = Matrix(((1.0, 0.0, 0.0), (0.0, 0.0, 1.0), (0.0, -1.0, 0.0)))
_C4 = _C.to_4x4()
_C4_INV = _C4.inverted()

_FLOAT_DECIMALS = 5

# Geometry Nodes can scatter hundreds of thousands of evaluated instances.
# Protocol 1 must realize those copies into JSON geometry for SceneKit, so an
# unbounded export can exceed both phone memory and the websocket message cap.
# Keep enough repeated detail for a faithful mobile preview while preventing
# a single foliage system from monopolizing the transfer.
_MAX_REALIZED_INSTANCE_TRIANGLES = 1_000_000


def _rounded(seq):
    return [round(float(v), _FLOAT_DECIMALS) for v in seq]


def _swizzle_np(arr):
    """(N,3) Blender-space → (N,3) iOS-space: (x, y, z) → (x, z, -y)."""
    out = np.empty_like(arr)
    out[:, 0] = arr[:, 0]
    out[:, 1] = arr[:, 2]
    out[:, 2] = -arr[:, 1]
    return out


def convert_matrix(matrix_world):
    """Blender world matrix → iOS-space loc / quaternion / scale dict.

    Conjugation (C·M·C⁻¹) — the transform as a mapping of POINTS in the new
    basis. Use for object transforms: the iOS side applies deltas
    (M_new · M_base⁻¹) to world-space-baked vertices, and conjugated deltas
    move points exactly right.
    """
    m = _C4 @ matrix_world @ _C4_INV
    loc, quat, scale = m.decompose()
    return {
        "location": _rounded(loc),
        "rotation_quat": _rounded([quat.x, quat.y, quat.z, quat.w]),
        "scale": _rounded(scale),
    }


def convert_matrix_oriented(matrix_world):
    """Blender world matrix → iOS transform for CAMERAS and LIGHTS: C·M
    (no right factor).

    Cameras and directional lights render along their LOCAL -Z in both
    Blender and SceneKit. Conjugation relabels the local frame — the node's
    -Z would end up aiming along Blender's local +Y (the camera's up), which
    pointed every Blender camera 90° off and gave a blank viewport. With
    R' = C·R each local axis maps through C directly: forward stays forward,
    up stays up.
    """
    m = _C4 @ matrix_world
    loc, quat, scale = m.decompose()
    return {
        "location": _rounded(loc),
        "rotation_quat": _rounded([quat.x, quat.y, quat.z, quat.w]),
        "scale": _rounded(scale),
    }


# ---------------------------------------------------------------------------
# Meshes
# ---------------------------------------------------------------------------

def _mesh_payload(obj, depsgraph, matrix_world=None):
    """Evaluated mesh (modifiers/geo-nodes baked) → geometry arrays.

    Vertices are expanded per loop corner so split normals shade correctly.
    A separate compact vertex array + original edge list drives the quad/ngon
    wireframe (never triangulated diagonals).
    """
    eval_obj = obj.evaluated_get(depsgraph)
    try:
        mesh = eval_obj.to_mesh()
    except RuntimeError:
        return None
    try:
        mesh.calc_loop_triangles()

        n_verts = len(mesh.vertices)
        n_loops = len(mesh.loops)
        n_tris = len(mesh.loop_triangles)
        if n_verts == 0 or n_tris == 0:
            return None

        mw = np.array(matrix_world or obj.matrix_world, dtype=np.float64)

        # Original vertices → world space
        co = np.empty(n_verts * 3, dtype=np.float64)
        mesh.vertices.foreach_get("co", co)
        co = co.reshape(n_verts, 3)
        co_world = co @ mw[:3, :3].T + mw[:3, 3]
        co_ios = _swizzle_np(co_world)

        # Per-corner expansion
        loop_vidx = np.empty(n_loops, dtype=np.int64)
        mesh.loops.foreach_get("vertex_index", loop_vidx)
        positions = co_ios[loop_vidx]

        # Corner normals (Blender 4.1+ replacement for calc_normals_split)
        normals = np.empty(n_loops * 3, dtype=np.float64)
        mesh.corner_normals.foreach_get("vector", normals)
        normals = normals.reshape(n_loops, 3)
        nrm_mat = np.linalg.inv(mw[:3, :3]).T
        normals = normals @ nrm_mat.T
        lengths = np.linalg.norm(normals, axis=1, keepdims=True)
        lengths[lengths == 0.0] = 1.0
        normals = _swizzle_np(normals / lengths)

        # Triangles index into the corner arrays
        tris = np.empty(n_tris * 3, dtype=np.int64)
        mesh.loop_triangles.foreach_get("loops", tris)

        tri_mat_index = np.empty(n_tris, dtype=np.int64)
        mesh.loop_triangles.foreach_get("material_index", tri_mat_index)

        # UVs (active layer), per corner. V flipped for SceneKit's texture space.
        uvs = None
        uv_layer = mesh.uv_layers.active
        if uv_layer is not None and len(uv_layer.data) == n_loops:
            uv = np.empty(n_loops * 2, dtype=np.float64)
            uv_layer.data.foreach_get("uv", uv)
            uv = uv.reshape(n_loops, 2)
            uv[:, 1] = 1.0 - uv[:, 1]
            uvs = uv

        # Blender's painted/procedural scenes commonly drive shader color from
        # mesh color attributes instead of image textures. Preserve one color
        # per expanded corner, choosing the layer used by that corner's
        # material (and falling back to the mesh's active render color).
        colors = _corner_colors(mesh, eval_obj, loop_vidx)

        # Original edges for wireframe (quads/ngons, not triangulation)
        n_edges = len(mesh.edges)
        wire_edges = np.empty(n_edges * 2, dtype=np.int64)
        mesh.edges.foreach_get("vertices", wire_edges)

        rnd = _FLOAT_DECIMALS
        payload = {
            "positions": np.round(positions.reshape(-1), rnd).tolist(),
            "normals": np.round(normals.reshape(-1), rnd).tolist(),
            "triangles": tris.tolist(),
            "triangle_material_index": tri_mat_index.tolist(),
            "wire_positions": np.round(co_ios.reshape(-1), rnd).tolist(),
            "wire_edges": wire_edges.tolist(),
            "stats": {
                "vertices": n_verts,
                "triangles": n_tris,
                "corners": n_loops,
                "edges": n_edges,
            },
        }
        if uvs is not None:
            payload["uvs"] = np.round(uvs.reshape(-1), rnd).tolist()
        if colors is not None:
            rgba8 = np.rint(colors * 255.0).astype(np.uint8, copy=False)
            payload["colors_rgba8"] = base64.b64encode(rgba8.tobytes()).decode("ascii")
        return payload
    finally:
        eval_obj.to_mesh_clear()


def _geometry_dimensions(geometry):
    positions = np.asarray(geometry["wire_positions"], dtype=np.float64).reshape(-1, 3)
    if len(positions) == 0:
        return [0.0, 0.0, 0.0]
    return _rounded(positions.max(axis=0) - positions.min(axis=0))


def _batch_instance_geometry(geometry, matrices_world, material_offsets):
    """Vectorized world-space realization for many copies of one mesh."""
    count = len(matrices_world)
    if count == 0:
        return None
    ios_matrices = np.asarray([
        np.asarray(_C4 @ matrix @ _C4_INV, dtype=np.float64)
        for matrix in matrices_world
    ])
    linear = ios_matrices[:, :3, :3]
    translation = ios_matrices[:, :3, 3]

    positions = np.asarray(geometry["positions"], dtype=np.float64).reshape(-1, 3)
    normals = np.asarray(geometry["normals"], dtype=np.float64).reshape(-1, 3)
    wire_positions = np.asarray(
        geometry["wire_positions"], dtype=np.float64
    ).reshape(-1, 3)
    transformed_positions = (
        np.einsum("kij,nj->kni", linear, positions) + translation[:, None, :]
    )
    transformed_wire = (
        np.einsum("kij,nj->kni", linear, wire_positions)
        + translation[:, None, :]
    )
    try:
        normal_matrices = np.linalg.inv(linear).transpose(0, 2, 1)
    except np.linalg.LinAlgError:
        # Zero-scaled instances are legal in Blender.  Their normals are not
        # meaningful, but a pseudo-inverse keeps the rest of the snapshot
        # exportable instead of aborting the whole scene.
        normal_matrices = np.linalg.pinv(linear).transpose(0, 2, 1)
    transformed_normals = np.einsum("kij,nj->kni", normal_matrices, normals)
    lengths = np.linalg.norm(transformed_normals, axis=2, keepdims=True)
    lengths[lengths == 0.0] = 1.0
    transformed_normals /= lengths

    triangle_template = np.asarray(geometry["triangles"], dtype=np.int64)
    triangle_offsets = (
        np.arange(count, dtype=np.int64) * len(positions)
    )[:, None]
    wire_template = np.asarray(geometry["wire_edges"], dtype=np.int64)
    wire_offsets = (
        np.arange(count, dtype=np.int64) * len(wire_positions)
    )[:, None]
    material_template = np.asarray(
        geometry["triangle_material_index"], dtype=np.int64
    )
    material_offsets = np.asarray(material_offsets, dtype=np.int64)[:, None]

    merged = {
        "positions": np.round(transformed_positions, _FLOAT_DECIMALS).reshape(-1).tolist(),
        "normals": np.round(transformed_normals, _FLOAT_DECIMALS).reshape(-1).tolist(),
        "triangles": (triangle_template[None, :] + triangle_offsets).reshape(-1).tolist(),
        "triangle_material_index": (
            material_template[None, :] + material_offsets
        ).reshape(-1).tolist(),
        "wire_positions": np.round(
            transformed_wire, _FLOAT_DECIMALS
        ).reshape(-1).tolist(),
        "wire_edges": (wire_template[None, :] + wire_offsets).reshape(-1).tolist(),
        "stats": {key: value * count for key, value in geometry["stats"].items()},
    }
    if "uvs" in geometry:
        merged["uvs"] = np.tile(
            np.asarray(geometry["uvs"], dtype=np.float64), count
        ).tolist()
    if "colors_rgba8" in geometry:
        colors = base64.b64decode(geometry["colors_rgba8"])
        merged["colors_rgba8"] = base64.b64encode(colors * count).decode("ascii")
    return merged


def object_binary_frame(message):
    """Encode one ``object_add`` as compact metadata + binary geometry.

    The body intentionally matches ``OfflineGeometryCodec`` in the iOS app,
    so live and offline geometry use one validated decoder.  Large scenes are
    typically 3-5x smaller than JSON and avoid millions of decimal parses.
    """
    if message.get("type") != "object_add":
        raise ValueError("binary geometry requires object_add")
    geometry = message["object"]["geometry"]
    header = dict(message)
    header_object = dict(message["object"])
    header_geometry = {
        "positions": [],
        "normals": [],
        "uvs": None,
        "triangles": [],
        "triangle_material_index": [],
        "wire_positions": [],
        "wire_edges": [],
        "stats": geometry["stats"],
    }
    header_object["geometry"] = header_geometry
    header["object"] = header_object
    header_bytes = json.dumps(header, separators=(",", ":")).encode("utf-8")

    body = bytearray(b"BVG1")

    def append_count(count):
        if count < 0 or count > 0xFFFFFFFE:
            raise ValueError("geometry array is too large")
        body.extend(struct.pack("<I", count))

    def append_array(values, dtype):
        array = np.asarray(values, dtype=dtype)
        append_count(array.size)
        body.extend(array.tobytes(order="C"))

    append_array(geometry["positions"], "<f4")
    append_array(geometry["normals"], "<f4")
    if "uvs" in geometry:
        append_array(geometry["uvs"], "<f4")
    else:
        body.extend(struct.pack("<I", 0xFFFFFFFF))
    colors = base64.b64decode(geometry.get("colors_rgba8", ""))
    append_count(len(colors))
    body.extend(colors)
    append_array(geometry["triangles"], "<u4")
    append_array(geometry["triangle_material_index"], "<i4")
    append_array(geometry["wire_positions"], "<f4")
    append_array(geometry["wire_edges"], "<u4")
    return b"BVO1" + struct.pack(">I", len(header_bytes)) + header_bytes + body


# ---------------------------------------------------------------------------
# Materials / textures
# ---------------------------------------------------------------------------

def _material_vertex_color_layer(mat):
    """Return the most likely display-color attribute used by ``mat``."""
    if not mat or not mat.use_nodes or not mat.node_tree:
        return None
    layers = []
    for node in _all_nodes_recursive(mat.node_tree):
        if node.bl_idname == "ShaderNodeVertexColor":
            layers.append(getattr(node, "layer_name", "") or "")
    if not layers:
        return None
    if "Attribute" in layers:
        return "Attribute"
    if "" in layers:
        return ""
    return layers[0]


def _material_surface_is_unlit(mat):
    """Whether the active material surface is authored as emission/unlit."""
    if not mat or not mat.use_nodes or not mat.node_tree:
        return False
    outputs = [node for node in mat.node_tree.nodes
               if node.bl_idname == "ShaderNodeOutputMaterial"
               and node.is_active_output]
    if not outputs:
        return False
    surface = outputs[0].inputs.get("Surface")
    if surface is None or not surface.is_linked:
        return False
    link = surface.links[0]
    return (link.from_node.bl_idname == "ShaderNodeEmission"
            or "emission" in link.from_socket.name.lower())


def _color_attribute_values(attribute, n_loops, loop_vidx):
    """Color attribute as per-corner sRGB RGBA, or ``None`` if incompatible."""
    count = len(attribute.data)
    if count == 0:
        return None
    values = np.empty(count * 4, dtype=np.float64)
    try:
        attribute.data.foreach_get("color_srgb", values)
    except (AttributeError, TypeError):
        attribute.data.foreach_get("color", values)
    values = values.reshape(count, 4)
    if attribute.domain == "CORNER" and count == n_loops:
        return values
    if attribute.domain == "POINT" and len(loop_vidx) and count > int(loop_vidx.max()):
        return values[loop_vidx]
    return None


def _corner_colors(mesh, eval_obj, loop_vidx):
    """Build a material-aware RGBA array matching the expanded loop vertices."""
    attributes = getattr(mesh, "color_attributes", None)
    if not attributes or len(attributes) == 0:
        return None
    active = getattr(attributes, "active_color", None)
    active_name = active.name if active is not None else attributes[0].name

    slot_layers = []
    for slot in eval_obj.material_slots:
        requested = _material_vertex_color_layer(slot.material)
        slot_layers.append(requested or active_name)
    if not slot_layers:
        slot_layers = [active_name]

    arrays = {}
    for name in set(slot_layers + [active_name]):
        attribute = attributes.get(name) or attributes.get(active_name)
        if attribute is not None:
            array = _color_attribute_values(attribute, len(mesh.loops), loop_vidx)
            if array is not None:
                arrays[name] = array
    fallback = arrays.get(active_name)
    if fallback is None and arrays:
        fallback = next(iter(arrays.values()))
    if fallback is None:
        return None

    colors = fallback.copy()
    for polygon in mesh.polygons:
        slot = polygon.material_index
        layer = slot_layers[slot] if 0 <= slot < len(slot_layers) else active_name
        source = arrays.get(layer, fallback)
        start = polygon.loop_start
        end = start + polygon.loop_total
        colors[start:end] = source[start:end]
    return np.clip(colors, 0.0, 1.0)

_MAX_TEXTURE_SIZE = 2048
_MAX_TEXTURE_CACHE_BYTES = 256 * 1024 * 1024
_MAX_TEXTURE_CACHE_ITEMS = 128
_texture_cache = OrderedDict()  # hex id -> encoded PNG bytes (LRU)
_texture_cache_bytes = 0
_image_texture_ids = {}   # image pointer -> hex id for current contents
_image_texture_signatures = {}  # pointer -> identity/content signature
_file_texture_ids = {}    # (absolute path, mtime ns, size) -> hex id
_derived_scalar_texture_ids = {}  # graph/image signature -> derived texture id
_last_viewport_environment = None


def clear_texture_caches():
    """Forget image identities when a new .blend file is loaded."""
    global _texture_cache_bytes, _last_viewport_environment
    _texture_cache.clear()
    _texture_cache_bytes = 0
    _image_texture_ids.clear()
    _image_texture_signatures.clear()
    _file_texture_ids.clear()
    _derived_scalar_texture_ids.clear()
    _last_viewport_environment = None


def _linear_channel_to_srgb(value):
    """Blender shader colors are scene-linear; UIKit color components are sRGB."""
    value = max(0.0, float(value))
    if value <= 0.0031308:
        return 12.92 * value
    return 1.055 * pow(value, 1.0 / 2.4) - 0.055


def _linear_color_to_srgb(value):
    rgba = list(value)
    converted = [_linear_channel_to_srgb(v) for v in rgba[:3]]
    if len(rgba) > 3:
        converted.append(float(rgba[3]))
    return _rounded(converted)


def _image_signature(image):
    """Stable-enough identity that catches Blender pointer reuse on file load."""
    library = getattr(getattr(image, "library", None), "filepath", "")
    size = tuple(int(value) for value in image.size)
    path = ""
    file_state = None
    try:
        path = bpy.path.abspath(image.filepath, library=image.library)
        if path and os.path.isfile(path):
            stat = os.stat(path)
            path = os.path.realpath(path)
            file_state = (stat.st_mtime_ns, stat.st_size)
    except (AttributeError, OSError, TypeError):
        pass
    return (image.name_full, image.source, size, library, path, file_state)


def _cached_texture(texture_id):
    data = _texture_cache.get(texture_id)
    if data is not None:
        _texture_cache.move_to_end(texture_id)
    return data


def _store_texture(texture_id, data):
    """Bound encoded-image memory across long edit/snapshot sessions."""
    global _texture_cache_bytes
    previous = _texture_cache.pop(texture_id, None)
    if previous is not None:
        _texture_cache_bytes -= len(previous)
    _texture_cache[texture_id] = data
    _texture_cache_bytes += len(data)
    evicted = set()
    while (_texture_cache_bytes > _MAX_TEXTURE_CACHE_BYTES
           or len(_texture_cache) > _MAX_TEXTURE_CACHE_ITEMS):
        old_id, old_data = _texture_cache.popitem(last=False)
        _texture_cache_bytes -= len(old_data)
        evicted.add(old_id)
    if evicted:
        for key, value in list(_image_texture_ids.items()):
            if value in evicted:
                del _image_texture_ids[key]
                _image_texture_signatures.pop(key, None)
        for key, value in list(_file_texture_ids.items()):
            if value in evicted:
                del _file_texture_ids[key]

def _active_surface_nodes(mat):
    if not mat or not mat.use_nodes or not mat.node_tree:
        return []
    outputs = [node for node in mat.node_tree.nodes
               if node.bl_idname == "ShaderNodeOutputMaterial"]
    active = next((node for node in outputs
                   if getattr(node, "is_active_output", False)), None)
    active = active or (outputs[0] if outputs else None)
    surface = active.inputs.get("Surface") if active else None
    pending = [link.from_node for link in surface.links] if surface else []
    seen = set()
    ordered = []
    while pending:
        node = pending.pop(0)
        key = node.as_pointer()
        if key in seen:
            continue
        seen.add(key)
        ordered.append(node)
        for socket in node.inputs:
            pending.extend(link.from_node for link in socket.links)
    return ordered


def _all_nodes_recursive(node_tree, seen=None):
    """Walk nested shader groups; many production files wrap the BSDF."""
    if node_tree is None:
        return
    seen = seen if seen is not None else set()
    pointer = node_tree.as_pointer()
    if pointer in seen:
        return
    seen.add(pointer)
    for node in node_tree.nodes:
        yield node
        nested = getattr(node, "node_tree", None)
        if nested is not None:
            yield from _all_nodes_recursive(nested, seen)


def _find_principled(mat):
    for node in _active_surface_nodes(mat):
        if node.bl_idname == "ShaderNodeBsdfPrincipled":
            return node
    if not mat or not mat.use_nodes or not mat.node_tree:
        return None
    for node in _all_nodes_recursive(mat.node_tree):
        if node.bl_idname == "ShaderNodeBsdfPrincipled":
            return node
    return None


def _find_legacy_surface(mat):
    """Nearest color-bearing shader connected to the active material output."""
    supported = {
        "ShaderNodeBsdfDiffuse", "ShaderNodeBsdfAnisotropic",
        "ShaderNodeBsdfGlossy", "ShaderNodeBsdfGlass",
        "ShaderNodeBsdfTranslucent", "ShaderNodeBsdfTransparent",
        "ShaderNodeSubsurfaceScattering", "ShaderNodeEmission",
    }
    active = next((node for node in _active_surface_nodes(mat)
                   if node.bl_idname in supported), None)
    if active is not None:
        return active
    if mat and mat.use_nodes and mat.node_tree:
        return next((node for node in _all_nodes_recursive(mat.node_tree)
                     if node.bl_idname in supported), None)
    return None


def _input_value(node, *names):
    """First existing input by name — socket names drift between 4.x and 5.x."""
    for name in names:
        sock = node.inputs.get(name)
        if sock is not None:
            return sock
    return None


def _linked_image(socket):
    """Find the nearest Image Texture feeding a Principled input.

    Transparent utility nodes (normal color correction, Mix, etc.) are
    traversed breadth-first. This covers direct links and common authored
    node graphs without assuming node names.
    """
    if socket is None or not socket.is_linked:
        return None
    pending = [link.from_node for link in socket.links]
    seen = set()
    while pending:
        node = pending.pop(0)
        key = node.as_pointer()
        if key in seen:
            continue
        seen.add(key)
        if node.bl_idname == "ShaderNodeTexImage" and node.image is not None:
            return node.image
        for input_socket in node.inputs:
            pending.extend(link.from_node for link in input_socket.links)
    return None


def _linked_texture(socket):
    """Return (image, source channel) for a linked scalar/color socket.

    Principled workflows commonly pack roughness/metallic/AO into RGB.  The
    channel is determined from the first Separate Color/RGB output on the
    path, while still walking through utility nodes to the image itself.
    """
    if socket is None or not socket.is_linked:
        return None, None
    pending = [(link.from_node, link.from_socket.name) for link in socket.links]
    seen = set()
    while pending:
        node, channel = pending.pop(0)
        key = (node.as_pointer(), channel)
        if key in seen:
            continue
        seen.add(key)
        if node.bl_idname == "ShaderNodeTexImage" and node.image is not None:
            value = channel.lower()
            mapped = {"red": "red", "r": "red", "green": "green", "g": "green",
                      "blue": "blue", "b": "blue", "alpha": "alpha", "a": "alpha"}
            return node.image, mapped.get(value, "rgb")
        inherited = channel
        if node.bl_idname in {"ShaderNodeSeparateColor", "ShaderNodeSeparateRGB"}:
            inherited = channel
        for input_socket in node.inputs:
            for link in input_socket.links:
                pending.append((link.from_node, inherited))
    return None, None


def _socket_scalar_default(socket):
    value = getattr(socket, "default_value", 0.0)
    if isinstance(value, (int, float)):
        return float(value)
    try:
        values = list(value)
    except TypeError:
        return 0.0
    if len(values) >= 3:
        return (0.2126 * float(values[0]) + 0.7152 * float(values[1])
                + 0.0722 * float(values[2]))
    return float(values[0]) if values else 0.0


def _representative_scalar(socket, object_random=0.5, seen=None):
    """Approximate a procedural scalar graph at a neutral sample.

    SceneKit cannot execute Blender shader nodes.  This fallback preserves a
    useful authored material colour when a graph has no image to transport.
    Image-backed channels still take the exact texture path above.
    """
    if socket is None or not socket.is_linked:
        return _socket_scalar_default(socket)
    link = socket.links[0]
    node, output = link.from_node, link.from_socket
    seen = set() if seen is None else set(seen)
    key = (node.as_pointer(), output.identifier)
    if key in seen:
        return _socket_scalar_default(socket)
    seen.add(key)
    kind = node.bl_idname
    if kind == "ShaderNodeObjectInfo" and output.name == "Random":
        return float(object_random)
    if kind in {"ShaderNodeTexNoise", "ShaderNodeTexVoronoi",
                "ShaderNodeTexWave", "ShaderNodeTexMusgrave"}:
        return 0.5
    if kind == "ShaderNodeValToRGB":
        factor = _representative_scalar(node.inputs.get("Fac"), object_random, seen)
        color = node.color_ramp.evaluate(min(max(factor, 0.0), 1.0))
        return 0.2126 * color[0] + 0.7152 * color[1] + 0.0722 * color[2]
    if kind == "ShaderNodeMapRange":
        value = _representative_scalar(node.inputs.get("Value"), object_random, seen)
        from_min = _socket_scalar_default(node.inputs.get("From Min"))
        from_max = _socket_scalar_default(node.inputs.get("From Max"))
        to_min = _socket_scalar_default(node.inputs.get("To Min"))
        to_max = _socket_scalar_default(node.inputs.get("To Max"))
        factor = 0.0 if abs(from_max - from_min) < 1e-12 else ((value - from_min) / (from_max - from_min))
        if getattr(node, "clamp", False):
            factor = min(max(factor, 0.0), 1.0)
        return to_min + factor * (to_max - to_min)
    if kind == "ShaderNodeMath":
        values = [_representative_scalar(sock, object_random, seen)
                  for sock in node.inputs[:3]]
        while len(values) < 3:
            values.append(0.0)
        a, b, c = values
        operations = {
            "ADD": lambda: a + b,
            "SUBTRACT": lambda: a - b,
            "MULTIPLY": lambda: a * b,
            "DIVIDE": lambda: a / b if abs(b) > 1e-12 else 0.0,
            "MULTIPLY_ADD": lambda: a * b + c,
            "POWER": lambda: pow(max(a, 0.0), b),
            "MINIMUM": lambda: min(a, b),
            "MAXIMUM": lambda: max(a, b),
            "LESS_THAN": lambda: 1.0 if a < b else 0.0,
            "GREATER_THAN": lambda: 1.0 if a > b else 0.0,
            "ABSOLUTE": lambda: abs(a),
            "FLOOR": lambda: math.floor(a),
            "CEIL": lambda: math.ceil(a),
            "FRACT": lambda: a - math.floor(a),
        }
        operation = operations.get(node.operation)
        if operation is not None:
            try:
                value = float(operation())
                if getattr(node, "use_clamp", False):
                    value = min(max(value, 0.0), 1.0)
                return value if math.isfinite(value) else _socket_scalar_default(socket)
            except (ArithmeticError, OverflowError, ValueError):
                pass
    if kind == "NodeReroute" and node.inputs:
        return _representative_scalar(node.inputs[0], object_random, seen)
    return _socket_scalar_default(socket)


def _socket_color_default(socket):
    value = getattr(socket, "default_value", (0.8, 0.8, 0.8, 1.0))
    try:
        values = [float(component) for component in value]
    except TypeError:
        scalar = float(value) if isinstance(value, (int, float)) else 0.8
        return [scalar, scalar, scalar, 1.0]
    if len(values) < 4:
        values.extend([1.0] * (4 - len(values)))
    return values[:4]


def _representative_color(socket, object_random=0.5, seen=None):
    """Return a representative linear RGBA value for a procedural colour."""
    if socket is None or not socket.is_linked:
        return _socket_color_default(socket)
    link = socket.links[0]
    node, output = link.from_node, link.from_socket
    seen = set() if seen is None else set(seen)
    key = (node.as_pointer(), output.identifier)
    if key in seen:
        return _socket_color_default(socket)
    seen.add(key)
    kind = node.bl_idname
    if kind == "ShaderNodeRGB":
        return _socket_color_default(node.outputs.get("Color"))
    if kind == "ShaderNodeValToRGB":
        factor = _representative_scalar(node.inputs.get("Fac"), object_random, seen)
        return list(node.color_ramp.evaluate(min(max(factor, 0.0), 1.0)))
    if kind in {"ShaderNodeMix", "ShaderNodeMixRGB"}:
        if kind == "ShaderNodeMix":
            factor = next((s for s in node.inputs
                           if s.identifier == "Factor_Float"), None)
            a = next((s for s in node.inputs if s.identifier == "A_Color"), None)
            b = next((s for s in node.inputs if s.identifier == "B_Color"), None)
        else:
            factor = node.inputs.get("Fac")
            a, b = node.inputs[1], node.inputs[2]
        f = min(max(_representative_scalar(factor, object_random, seen), 0.0), 1.0)
        ca = _representative_color(a, object_random, seen)
        cb = _representative_color(b, object_random, seen)
        return [(1.0 - f) * ca[i] + f * cb[i] for i in range(4)]
    if kind == "NodeReroute" and node.inputs:
        return _representative_color(node.inputs[0], object_random, seen)
    if kind in {"ShaderNodeTexNoise", "ShaderNodeTexVoronoi",
                "ShaderNodeTexWave", "ShaderNodeTexMusgrave"}:
        value = 0.5
        return [value, value, value, 1.0]
    return _socket_color_default(socket)


def _evaluate_scalar_socket(socket, source_image, source_value, seen=None):
    """Evaluate the common scalar node path with an image channel = x.

    This intentionally supports the production PBR utilities Blender artists
    commonly place between a packed map and Principled: Separate Color, Math,
    Color Ramp, RGB to BW and Clamp. Unknown nodes return ``supported=False``
    so transport safely falls back to the original channel.
    """
    if socket is None or not socket.is_linked:
        return _socket_scalar_default(socket), True
    link = socket.links[0]
    return _evaluate_scalar_output(
        link.from_node, link.from_socket, source_image, source_value,
        seen if seen is not None else set()
    )


def _evaluate_scalar_output(node, output, source_image, source_value, seen):
    key = (node.as_pointer(), output.identifier)
    if key in seen:
        return source_value, False
    seen = set(seen)
    seen.add(key)
    kind = node.bl_idname

    if kind == "ShaderNodeTexImage":
        return (source_value, node.image == source_image)
    if kind in {"ShaderNodeSeparateColor", "ShaderNodeSeparateRGB"}:
        return source_value, True
    if kind == "ShaderNodeRGBToBW":
        return _evaluate_scalar_socket(node.inputs.get("Color"), source_image,
                                       source_value, seen)
    if kind == "ShaderNodeClamp":
        value, ok = _evaluate_scalar_socket(node.inputs.get("Value"), source_image,
                                            source_value, seen)
        minimum = _socket_scalar_default(node.inputs.get("Min"))
        maximum = _socket_scalar_default(node.inputs.get("Max"))
        return min(max(value, minimum), maximum), ok
    if kind == "ShaderNodeValToRGB":
        factor, ok = _evaluate_scalar_socket(node.inputs.get("Fac"), source_image,
                                             source_value, seen)
        color = node.color_ramp.evaluate(min(max(factor, 0.0), 1.0))
        return (0.2126 * color[0] + 0.7152 * color[1] + 0.0722 * color[2]), ok
    if kind == "ShaderNodeMath":
        values = []
        ok = True
        for input_socket in node.inputs[:3]:
            value, input_ok = _evaluate_scalar_socket(
                input_socket, source_image, source_value, seen
            )
            values.append(value)
            ok = ok and input_ok
        while len(values) < 3:
            values.append(0.0)
        a, b, c = values
        operation = node.operation
        try:
            result = {
                "ADD": lambda: a + b,
                "SUBTRACT": lambda: a - b,
                "MULTIPLY": lambda: a * b,
                "DIVIDE": lambda: a / b if abs(b) > 1e-12 else 0.0,
                "MULTIPLY_ADD": lambda: a * b + c,
                "POWER": lambda: pow(max(a, 0.0), b),
                "MINIMUM": lambda: min(a, b),
                "MAXIMUM": lambda: max(a, b),
                "LESS_THAN": lambda: 1.0 if a < b else 0.0,
                "GREATER_THAN": lambda: 1.0 if a > b else 0.0,
                "ABSOLUTE": lambda: abs(a),
                "FLOOR": lambda: math.floor(a),
                "CEIL": lambda: math.ceil(a),
                "FRACT": lambda: a - math.floor(a),
                "MODULO": lambda: a % b if abs(b) > 1e-12 else 0.0,
                "PINGPONG": lambda: abs((a % (2 * b)) - b)
                    if abs(b) > 1e-12 else 0.0,
            }.get(operation)
            if result is None:
                return source_value, False
            value = float(result())
            if getattr(node, "use_clamp", False):
                value = min(max(value, 0.0), 1.0)
            return value, ok and math.isfinite(value)
        except (ArithmeticError, OverflowError, ValueError):
            return source_value, False
    return source_value, False


def _scalar_transfer_samples(socket, image):
    values = []
    for index in range(257):
        value, supported = _evaluate_scalar_socket(
            socket, image, index / 256.0
        )
        if not supported or not math.isfinite(value):
            return None
        values.append(min(max(float(value), 0.0), 1.0))
    return np.asarray(values, dtype=np.float32)


def _encode_scalar_texture_png(image, channel, samples):
    """Bake a supported scalar utility graph into a compact grayscale PNG."""
    work = image.copy()
    derived = None
    try:
        width, height = (int(work.size[0]), int(work.size[1]))
        longest = max(width, height)
        if longest > _MAX_TEXTURE_SIZE:
            ratio = _MAX_TEXTURE_SIZE / float(longest)
            width = max(1, round(width * ratio))
            height = max(1, round(height * ratio))
            work.scale(width, height)
        pixels = np.empty(width * height * 4, dtype=np.float32)
        work.pixels.foreach_get(pixels)
        pixels = pixels.reshape((-1, 4))
        indices = {"red": 0, "green": 1, "blue": 2, "alpha": 3}
        if channel in indices:
            source = pixels[:, indices[channel]]
        else:
            source = (pixels[:, 0] * 0.2126 + pixels[:, 1] * 0.7152
                      + pixels[:, 2] * 0.0722)
        transformed = np.interp(
            np.clip(source, 0.0, 1.0),
            np.linspace(0.0, 1.0, len(samples), dtype=np.float32), samples
        ).astype(np.float32, copy=False)
        rgba = np.empty((len(transformed), 4), dtype=np.float32)
        rgba[:, :3] = transformed[:, None]
        rgba[:, 3] = 1.0
        derived = bpy.data.images.new(
            "Blender Viewer Scalar", width=width, height=height, alpha=True
        )
        try:
            derived.colorspace_settings.name = "Non-Color"
        except TypeError:
            pass
        derived.pixels.foreach_set(rgba.reshape(-1))
        derived.update()
        return _encode_image_png(derived)
    finally:
        if derived is not None:
            bpy.data.images.remove(derived)
        bpy.data.images.remove(work)


def _scalar_texture_descriptor(socket):
    """Return a faithful scalar texture/constant for one Principled input."""
    image, channel = _linked_texture(socket)
    if image is None:
        return None
    samples = _scalar_transfer_samples(socket, image)
    if samples is None:
        texture_id, frame = texture_for_image(image)
        return {"id": texture_id, "frame": frame, "channel": channel,
                "name": image.name}
    if float(samples.max() - samples.min()) <= 1.0 / 65535.0:
        return {"constant": round(float(samples[0]), 5)}
    identity = np.linspace(0.0, 1.0, len(samples), dtype=np.float32)
    if np.max(np.abs(samples - identity)) <= 1.0 / 255.0:
        texture_id, frame = texture_for_image(image)
        return {"id": texture_id, "frame": frame, "channel": channel,
                "name": image.name}

    key = (_image_signature(image), channel,
           bytes(np.rint(samples * 255.0).astype(np.uint8)))
    texture_id = _derived_scalar_texture_ids.get(key)
    data = _cached_texture(texture_id)
    if data is None:
        data = _encode_scalar_texture_png(image, channel, samples)
        raw_id = hashlib.sha256(data).digest()[:16]
        texture_id = raw_id.hex()
        _store_texture(texture_id, data)
        _derived_scalar_texture_ids[key] = texture_id
    frame = bytes.fromhex(texture_id) + struct.pack(">I", len(data)) + data
    return {"id": texture_id, "frame": frame, "channel": "red",
            "name": f"{image.name} (baked scalar)"}


def _linked_node(socket, node_type):
    if socket is None or not socket.is_linked:
        return None
    pending = [link.from_node for link in socket.links]
    seen = set()
    while pending:
        node = pending.pop(0)
        key = node.as_pointer()
        if key in seen:
            continue
        seen.add(key)
        if node.bl_idname == node_type:
            return node
        for input_socket in node.inputs:
            pending.extend(link.from_node for link in input_socket.links)
    return None


def _fallback_color_image(mat):
    """Best base-color image for wrapped/custom shader groups.

    Group inputs hide the direct socket path from the nested BSDF. Prefer
    color-managed (non-data) images whose names identify albedo/base/diffuse.
    """
    if not mat or not mat.use_nodes or not mat.node_tree:
        return None
    candidates = []
    for node in _all_nodes_recursive(mat.node_tree):
        if node.bl_idname != "ShaderNodeTexImage" or node.image is None:
            continue
        image = node.image
        try:
            is_data = bool(image.colorspace_settings.is_data)
        except AttributeError:
            name = getattr(image.colorspace_settings, "name", "").lower()
            is_data = "non-color" in name or "data" == name
        if is_data:
            continue
        label = f"{node.name} {node.label} {image.name}".lower()
        score = sum(word in label for word in
                    ("base", "albedo", "diffuse", "color", "colour"))
        candidates.append((score, image))
    return max(candidates, key=lambda item: item[0])[1] if candidates else None


def _encode_image_png(image):
    """Return transport-safe PNG bytes, downscaled without mutating source."""
    copy = image.copy()
    fd, path = tempfile.mkstemp(prefix="blender-viewer-", suffix=".png")
    os.close(fd)
    try:
        width, height = copy.size
        longest = max(width, height)
        if longest > _MAX_TEXTURE_SIZE:
            ratio = _MAX_TEXTURE_SIZE / float(longest)
            copy.scale(max(1, round(width * ratio)), max(1, round(height * ratio)))
        copy.filepath_raw = path
        copy.file_format = "PNG"
        copy.save()
        with open(path, "rb") as handle:
            return handle.read()
    finally:
        try:
            bpy.data.images.remove(copy)
        except (ReferenceError, RuntimeError):
            pass
        try:
            os.unlink(path)
        except OSError:
            pass


def texture_for_image(image):
    """Encode/cache an image and return (hex id, binary frame)."""
    pointer = image.as_pointer()
    signature = _image_signature(image)
    cached_id = _image_texture_ids.get(pointer)
    data = _cached_texture(cached_id)
    if (data is not None and not image.is_dirty
            and _image_texture_signatures.get(pointer) == signature):
        raw_id = bytes.fromhex(cached_id)
        return cached_id, raw_id + struct.pack(">I", len(data)) + data

    file_key = None
    try:
        path = bpy.path.abspath(image.filepath, library=image.library)
        if path and os.path.isfile(path):
            stat = os.stat(path)
            file_key = (os.path.realpath(path), stat.st_mtime_ns, stat.st_size)
            cached_id = _file_texture_ids.get(file_key)
            data = _cached_texture(cached_id)
            if data is not None and not image.is_dirty:
                _image_texture_ids[pointer] = cached_id
                _image_texture_signatures[pointer] = signature
                raw_id = bytes.fromhex(cached_id)
                return cached_id, raw_id + struct.pack(">I", len(data)) + data
    except (AttributeError, OSError, TypeError):
        pass

    data = _encode_image_png(image)
    raw_id = hashlib.sha256(data).digest()[:16]
    texture_id = raw_id.hex()
    _store_texture(texture_id, data)
    _image_texture_ids[pointer] = texture_id
    _image_texture_signatures[pointer] = signature
    if file_key is not None:
        _file_texture_ids[file_key] = texture_id
    frame = raw_id + struct.pack(">I", len(data)) + data
    return texture_id, frame


def _evaluated_materials(obj, depsgraph):
    """Materials indexed by the evaluated mesh's polygon material indices."""
    evaluated = obj.evaluated_get(depsgraph)
    return [slot.material for slot in evaluated.material_slots]


def collect_textures(selected_only=False):
    """Encode PBR images and the active Material Preview environment."""
    global _last_viewport_environment
    textures = {}
    selected = set(selected_names()) if selected_only else None
    depsgraph = bpy.context.evaluated_depsgraph_get()
    for obj in bpy.context.scene.objects:
        if obj.type != "MESH" or not obj.visible_get():
            continue
        if selected is not None and obj.name not in selected:
            continue
        for material in _evaluated_materials(obj, depsgraph):
            shader = (_find_principled(material)
                      or _find_legacy_surface(material))
            if shader is None:
                continue
            found_color = False
            for names in (("Base Color", "Color"), ("Normal",)):
                image = _linked_image(_input_value(shader, *names))
                if image is None:
                    continue
                texture_id, frame = texture_for_image(image)
                textures[texture_id] = {
                    "id": texture_id,
                    "name": image.name,
                    "mime_type": "image/png",
                    "byte_count": len(frame) - 20,
                    "frame": frame,
                }
                if "Color" in names:
                    found_color = True
            for names in (("Metallic",), ("Roughness",)):
                descriptor = _scalar_texture_descriptor(
                    _input_value(shader, *names)
                )
                if descriptor is None or "frame" not in descriptor:
                    continue
                textures[descriptor["id"]] = {
                    "id": descriptor["id"],
                    "name": descriptor["name"],
                    "mime_type": "image/png",
                    "byte_count": len(descriptor["frame"]) - 20,
                    "frame": descriptor["frame"],
                }
            if not found_color and _material_vertex_color_layer(material) is None:
                image = _fallback_color_image(material)
                if image is not None:
                    texture_id, frame = texture_for_image(image)
                    textures[texture_id] = {
                        "id": texture_id,
                        "name": image.name,
                        "mime_type": "image/png",
                        "byte_count": len(frame) - 20,
                        "frame": frame,
                    }

    _last_viewport_environment = None
    shading = None
    for window in getattr(bpy.context.window_manager, "windows", []):
        for area in getattr(window.screen, "areas", []):
            if area.type == "VIEW_3D":
                shading = area.spaces.active.shading
                break
        if shading is not None:
            break
    if shading is not None and shading.type == "MATERIAL":
        studio_name = getattr(shading, "studio_light", "")
        studio = next((item for item in bpy.context.preferences.studio_lights
                       if item.name == studio_name), None)
        path = getattr(studio, "path", "") if studio else ""
        if path and os.path.exists(path):
            existing = bpy.data.images.get("Blender Viewer Material Preview")
            image = existing or bpy.data.images.load(path, check_existing=False)
            if existing is None:
                image.name = "Blender Viewer Material Preview"
            try:
                texture_id, frame = texture_for_image(image)
                textures[texture_id] = {
                    "id": texture_id,
                    "name": studio_name,
                    "mime_type": "image/png",
                    "byte_count": len(frame) - 20,
                    "frame": frame,
                }
                _last_viewport_environment = {
                    "texture": texture_id,
                    "name": studio_name,
                    # Background alpha only controls whether Blender draws the
                    # studio image behind the model.  It is not the light
                    # strength.  Export the Material Preview intensity so the
                    # iOS renderer can reproduce Blender's actual lighting.
                    "intensity": round(float(getattr(shading, "studiolight_intensity", 1.0)), 4),
                    "rotation": round(float(getattr(shading, "studiolight_rotate_z", 0.0)), 5),
                }
            finally:
                if existing is None:
                    bpy.data.images.remove(image)
    return textures


def material_payload(mat, object_random=0.5):
    vertex_color_layer = _material_vertex_color_layer(mat)
    out = {
        "name": mat.name if mat else "Default",
        "base_color": [0.8, 0.8, 0.8, 1.0],
        "metallic": 0.0,
        "roughness": 0.5,
        "emission_color": [0.0, 0.0, 0.0],
        "emission_strength": 0.0,
        "alpha": 1.0,
        "base_color_texture": None,  # texture id, Phase 4
        "metallic_texture": None,
        "metallic_texture_channel": None,
        "roughness_texture": None,
        "roughness_texture_channel": None,
        "normal_texture": None,
        "normal_strength": 1.0,
        "uses_vertex_color": False,
        "is_unlit": _material_surface_is_unlit(mat),
    }
    node = _find_principled(mat)
    if node is None:
        legacy = _find_legacy_surface(mat)
        if legacy is not None:
            color = _input_value(legacy, "Color")
            image = _linked_image(color)
            if image is not None:
                texture_id = _image_texture_ids.get(image.as_pointer())
                if texture_id is None:
                    texture_id, _ = texture_for_image(image)
                out["base_color_texture"] = texture_id
            elif vertex_color_layer is not None:
                out["uses_vertex_color"] = True
            elif vertex_color_layer is None and (image := _fallback_color_image(mat)) is not None:
                texture_id = _image_texture_ids.get(image.as_pointer())
                if texture_id is None:
                    texture_id, _ = texture_for_image(image)
                out["base_color_texture"] = texture_id
            elif color is not None:
                out["base_color"] = _linear_color_to_srgb(
                    _representative_color(color, object_random)
                )
            elif mat is not None:
                out["base_color"] = _linear_color_to_srgb(mat.diffuse_color)
            roughness = _input_value(legacy, "Roughness")
            if legacy.bl_idname == "ShaderNodeBsdfDiffuse":
                # Blender's Diffuse Roughness is an Oren-Nayar scattering
                # control, not the microfacet roughness SceneKit expects.
                # Mapping zero to zero creates a mirror that Blender never
                # displays, so keep diffuse-only surfaces fully matte.
                out["roughness"] = 1.0
            elif roughness is not None and not roughness.is_linked:
                out["roughness"] = round(float(roughness.default_value), 4)
            if legacy.bl_idname == "ShaderNodeEmission":
                out["emission_color"] = out["base_color"][:3]
                strength = _input_value(legacy, "Strength")
                out["emission_strength"] = round(
                    float(strength.default_value), 4
                ) if strength is not None and not strength.is_linked else 1.0
            return out
        if mat and not mat.use_nodes:
            out["base_color"] = _linear_color_to_srgb(mat.diffuse_color)
            out["metallic"] = round(float(mat.metallic), 4)
            out["roughness"] = round(float(mat.roughness), 4)
        return out

    base = _input_value(node, "Base Color")
    image = _linked_image(base)
    if image is None and vertex_color_layer is not None:
        out["uses_vertex_color"] = True
    if image is None and vertex_color_layer is None:
        image = _fallback_color_image(mat)
    if image is not None:
        texture_id = _image_texture_ids.get(image.as_pointer())
        if texture_id is None:
            texture_id, _ = texture_for_image(image)
        out["base_color_texture"] = texture_id
    elif base is not None:
        out["base_color"] = _linear_color_to_srgb(
            _representative_color(base, object_random)
        )
    elif mat is not None:
        out["base_color"] = _linear_color_to_srgb(mat.diffuse_color)
    metallic = _input_value(node, "Metallic")
    descriptor = _scalar_texture_descriptor(metallic)
    if descriptor is not None:
        if "constant" in descriptor:
            out["metallic"] = descriptor["constant"]
        else:
            out["metallic_texture"] = descriptor["id"]
            out["metallic_texture_channel"] = descriptor["channel"]
    if metallic is not None and not metallic.is_linked:
        out["metallic"] = round(float(metallic.default_value), 4)
    rough = _input_value(node, "Roughness")
    descriptor = _scalar_texture_descriptor(rough)
    if descriptor is not None:
        if "constant" in descriptor:
            out["roughness"] = descriptor["constant"]
        else:
            out["roughness_texture"] = descriptor["id"]
            out["roughness_texture_channel"] = descriptor["channel"]
    if rough is not None and not rough.is_linked:
        out["roughness"] = round(float(rough.default_value), 4)
    normal = _input_value(node, "Normal")
    image, _ = _linked_texture(normal)
    if image is not None:
        texture_id = _image_texture_ids.get(image.as_pointer())
        if texture_id is None:
            texture_id, _ = texture_for_image(image)
        out["normal_texture"] = texture_id
    normal_map = _linked_node(normal, "ShaderNodeNormalMap")
    if normal_map is not None:
        strength_socket = normal_map.inputs.get("Strength")
        if strength_socket is not None:
            out["normal_strength"] = round(float(strength_socket.default_value), 4)
    alpha = _input_value(node, "Alpha")
    if alpha is not None and not alpha.is_linked:
        out["alpha"] = round(float(alpha.default_value), 4)
    emission = _input_value(node, "Emission Color", "Emission")
    if emission is not None and not emission.is_linked:
        out["emission_color"] = _linear_color_to_srgb(
            list(emission.default_value)[:3]
        )
    strength = _input_value(node, "Emission Strength")
    if strength is not None and not strength.is_linked:
        out["emission_strength"] = round(float(strength.default_value), 4)
    return out


# ---------------------------------------------------------------------------
# Lights / cameras
# ---------------------------------------------------------------------------

_LIGHT_KIND = {"POINT": "point", "SUN": "sun", "SPOT": "spot", "AREA": "area"}


def light_payload(obj):
    light = obj.data
    kind = _LIGHT_KIND.get(light.type)
    if kind is None:
        return None
    transform = convert_matrix_oriented(obj.matrix_world)
    # Object scale changes an area light's physical dimensions in Blender, but
    # SceneKit does not consistently apply node scale to SCNLight.areaExtents.
    # Bake it into area_size and keep the light node transform rigid.
    transform["scale"] = [1.0, 1.0, 1.0]
    out = {
        "name": obj.name,
        "kind": kind,
        # oriented: sun/spot/area aim along local -Z on both sides
        "transform": transform,
        "color": _linear_color_to_srgb(light.color),
        "energy": round(float(light.energy), 3),
    }
    if light.type == "SPOT":
        out["spot_angle"] = round(float(light.spot_size), 5)
        out["spot_blend"] = round(float(light.spot_blend), 5)
    elif light.type == "AREA":
        size_y = light.size_y if light.shape in {"RECTANGLE", "ELLIPSE"} else light.size
        scale = obj.matrix_world.to_scale()
        out["area_size"] = [
            round(float(light.size) * abs(float(scale.x)), 5),
            round(float(size_y) * abs(float(scale.y)), 5),
        ]
    return out


def camera_payload(obj, active_name):
    cam = obj.data
    sensor = cam.sensor_width if cam.sensor_fit != "VERTICAL" else cam.sensor_height
    fov_deg = math.degrees(2.0 * math.atan(sensor / (2.0 * cam.lens)))
    return {
        "name": obj.name,
        "transform": convert_matrix_oriented(obj.matrix_world),
        "lens_mm": round(float(cam.lens), 3),
        "sensor_mm": round(float(sensor), 3),
        "sensor_fit": cam.sensor_fit,
        "fov_deg": round(fov_deg, 3),
        "is_active": obj.name == active_name,
    }


def viewport_camera_payload():
    """Current 3D viewport view as a pseudo-camera named 'Viewport'."""
    wm = bpy.context.window_manager
    if wm is None:
        return None
    for window in wm.windows:
        screen = window.screen
        if screen is None:
            continue
        for area in screen.areas:
            if area.type != "VIEW_3D":
                continue
            space = area.spaces.active
            r3d = getattr(space, "region_3d", None)
            if r3d is None:
                continue
            world = r3d.view_matrix.inverted()
            fov_deg = math.degrees(2.0 * math.atan(36.0 / (2.0 * space.lens)))
            return {
                "name": "Viewport",
                "transform": convert_matrix_oriented(world),
                "lens_mm": round(float(space.lens), 3),
                "sensor_mm": 36.0,
                "sensor_fit": "AUTO",
                "fov_deg": round(fov_deg, 3),
                "is_active": False,
                "is_viewport": True,
            }
    return None


# ---------------------------------------------------------------------------
# Selection / snapshot
# ---------------------------------------------------------------------------

def selected_names():
    try:
        return sorted(o.name for o in bpy.context.selected_objects)
    except AttributeError:
        return []


def _stable_object_random(name, persistent_id=()):
    identity = name + ":" + ",".join(str(value) for value in persistent_id)
    value = int.from_bytes(hashlib.sha256(identity.encode("utf-8")).digest()[:4], "big")
    return value / 4294967295.0


def _mesh_dimensions(obj, matrix_world):
    corners = np.asarray([list(corner) for corner in obj.bound_box], dtype=np.float64)
    matrix = np.asarray(matrix_world, dtype=np.float64)
    world = corners @ matrix[:3, :3].T + matrix[:3, 3]
    extents = world.max(axis=0) - world.min(axis=0)
    return _rounded([extents[0], extents[2], extents[1]])


def snapshot_messages(selected_only=False, snapshot_token=None):
    """Yield protocol-1 messages: scene_begin, N × object_add, scene_end.

    Chunked per object so the phone can render progressively.
    """
    depsgraph = bpy.context.evaluated_depsgraph_get()
    scene = bpy.context.scene

    objects = [
        o for o in scene.objects
        if o.type in {"MESH", "LIGHT", "CAMERA"} and o.visible_get()
    ]
    if selected_only:
        sel = set(selected_names())
        objects = [
            o for o in objects
            if o.name in sel or o.type == "CAMERA"  # cameras always ride along
        ]

    meshes = [o for o in objects if o.type == "MESH"]
    lights = [o for o in objects if o.type == "LIGHT"]
    cameras = [o for o in objects if o.type == "CAMERA"]
    selected = set(selected_names())

    mesh_entries = [
        {
            "name": obj.name,
            "object": obj,
            "matrix": obj.matrix_world.copy(),
            "random": _stable_object_random(obj.name),
        }
        for obj in meshes
    ]
    instance_groups = {}
    for instance in depsgraph.object_instances:
        if not instance.is_instance or instance.object.type != "MESH":
            continue
        parent = instance.parent.original if instance.parent else None
        if selected_only and (parent is None or parent.name not in selected):
            continue
        # Keep the evaluated instance object, not its original owner.  For
        # Geometry Nodes the original object's evaluated mesh can be the
        # complete host (tens of thousands of vertices), while
        # ``instance.object`` is the tiny instanced primitive.  Replacing it
        # with ``original`` multiplied the entire host mesh once per sprinkle
        # or leaf and could turn a sub-second snapshot into minutes of work.
        source = instance.object
        persistent_id = tuple(value for value in instance.persistent_id
                              if value != 2147483647)
        source_materials = _evaluated_materials(source, depsgraph)
        material_key = tuple(
            material.as_pointer() if material is not None else 0
            for material in source_materials
        )
        geometry_key = (
            source.data.as_pointer() if source.data is not None
            else source.as_pointer(),
            material_key,
        )
        group = instance_groups.get(geometry_key)
        if group is None:
            # Depsgraph instance wrappers are only guaranteed to stay valid
            # during this iteration.  Capture their small source mesh and
            # stable material datablocks now rather than retaining the proxy.
            group = {
                "name": (getattr(source, "original", None) or source).name,
                "geometry": _mesh_payload(
                    source, depsgraph, Matrix.Identity(4)
                ),
                "materials": source_materials,
                "instances": [],
            }
            instance_groups[geometry_key] = group
        group["instances"].append({
            "matrix": instance.matrix_world.copy(),
            "random": _stable_object_random(source.name, persistent_id),
        })

    snapshot_id = snapshot_messages._next_id
    snapshot_messages._next_id += 1

    yield {
        "type": "scene_begin",
        "protocol": PROTOCOL_VERSION,
        "snapshot_id": snapshot_id,
        "scene": {
            "name": scene.name,
            "frame": scene.frame_current,
            "fps": scene.render.fps / scene.render.fps_base,
        },
        "object_count": len(mesh_entries) + len(instance_groups),
    }

    totals = {"vertices": 0, "triangles": 0, "materials": 0}
    material_names = set()

    possible_instance_triangles = sum(
        len(group["instances"])
        * ((group["geometry"] or {}).get("stats", {}).get("triangles", 0))
        for group in instance_groups.values()
    )
    instance_ratio = min(
        1.0,
        _MAX_REALIZED_INSTANCE_TRIANGLES
        / max(possible_instance_triangles, 1),
    )

    for entry in mesh_entries:
        obj = entry["object"]
        matrix_world = entry["matrix"]
        geo = _mesh_payload(obj, depsgraph, matrix_world)
        if geo is None:
            continue
        materials = [
            material_payload(material, entry["random"])
            for material in _evaluated_materials(obj, depsgraph)
        ] or [material_payload(None)]
        for m in materials:
            material_names.add(m["name"])
        totals["vertices"] += geo["stats"]["vertices"]
        totals["triangles"] += geo["stats"]["triangles"]
        yield {
            "type": "object_add",
            "snapshot_id": snapshot_id,
            "object": {
                "name": entry["name"],
                "kind": "mesh",
                "transform": convert_matrix(matrix_world),
                "dimensions": _mesh_dimensions(obj, matrix_world),
                "materials": materials,
                "geometry": geo,
            },
        }

    # Geometry Nodes often keeps repeated geometry as dependency-graph
    # instances.  ``Object.to_mesh()`` does not include those instances, so
    # batch every source into one world-space object.  This preserves the
    # viewport result without sending hundreds of tiny websocket messages.
    for group in instance_groups.values():
        source_materials = group["materials"]
        local_geometry = group["geometry"]
        if local_geometry is None:
            continue
        all_instances = group["instances"]
        export_count = min(
            len(all_instances),
            max(1, int(len(all_instances) * instance_ratio)),
        )
        if export_count < len(all_instances):
            indices = (
                np.arange(export_count, dtype=np.int64)
                * len(all_instances) // export_count
            )
            instances = [all_instances[int(index)] for index in indices]
        else:
            instances = all_instances
        material_variants = []
        variant_offsets = {}
        instance_matrices = []
        instance_material_offsets = []
        for instance in instances:
            materials = [material_payload(material, instance["random"])
                         for material in source_materials] or [material_payload(None)]
            key = tuple(tuple(material["base_color"]) for material in materials)
            offset = variant_offsets.get(key)
            if offset is None:
                offset = len(material_variants)
                variant_offsets[key] = offset
                material_variants.extend(materials)
            instance_matrices.append(instance["matrix"])
            instance_material_offsets.append(offset)
        geo = _batch_instance_geometry(
            local_geometry,
            instance_matrices,
            instance_material_offsets,
        )
        if geo is None:
            continue
        for material in material_variants:
            material_names.add(material["name"])
        totals["vertices"] += geo["stats"]["vertices"]
        totals["triangles"] += geo["stats"]["triangles"]
        identity = Matrix.Identity(4)
        yield {
            "type": "object_add",
            "snapshot_id": snapshot_id,
            "object": {
                "name": f"{group['name']} [instances]",
                "kind": "mesh",
                "source_instance_count": len(all_instances),
                "exported_instance_count": len(instances),
                "transform": convert_matrix(identity),
                "dimensions": _geometry_dimensions(geo),
                "materials": material_variants,
                "geometry": geo,
            },
        }

    totals["materials"] = len(material_names)

    active_cam = scene.camera.name if scene.camera else None
    camera_list = [camera_payload(o, active_cam) for o in cameras]
    vp = viewport_camera_payload()
    if vp is not None:
        camera_list.append(vp)

    yield {
        "type": "scene_end",
        "snapshot_id": snapshot_id,
        "snapshot_token": snapshot_token,
        "lights": [p for p in (light_payload(o) for o in lights) if p],
        "cameras": camera_list,
        "active_camera": active_cam,
        "viewport_environment": _last_viewport_environment,
        "selected": selected_names(),
        "stats": {
            "objects": len(mesh_entries) + len(instance_groups),
            "lights": len(lights),
            "cameras": len(camera_list),
            **totals,
        },
    }


snapshot_messages._next_id = 1


def transform_update_message(obj_names):
    """Lightweight delta: just transforms for the named objects.

    Meshes get the conjugated form (the iOS delta path needs it);
    cameras and lights get the oriented form (their local -Z is meaningful).
    """
    scene_objects = bpy.context.scene.objects
    items = []
    for name in obj_names:
        obj = scene_objects.get(name)
        if obj is None:
            continue
        if obj.type in {"CAMERA", "LIGHT"}:
            transform = convert_matrix_oriented(obj.matrix_world)
        else:
            transform = convert_matrix(obj.matrix_world)
        items.append({"name": name, "transform": transform})
    return {"type": "transform_update", "objects": items}
