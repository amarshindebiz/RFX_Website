# SPDX-License-Identifier: GPL-3.0-or-later
"""
Live sync: depsgraph/frame handlers with a 250ms debounce so dragging a
vertex doesn't flood the socket. Handlers and the flush timer both run on
Blender's main thread.

Delta strategy: if every update since the last flush was transform-only,
send a lightweight transform_update; anything geometric triggers a full
snapshot broadcast. Selection changes always broadcast (cheap), even with
Live Sync off — selection sync is a core feature, not a "sync" feature.
"""

import time

import bpy
from bpy.app.handlers import persistent

from . import commands, serializer

DEBOUNCE_SECONDS = 0.25

_pending = {
    "transform_names": set(),
    "geometry_dirty": False,
    "last_change": 0.0,
    "timer_scheduled": False,
}
_last_selection = []


def _clients_connected():
    srv = commands.get_server()
    return srv is not None and srv.running and srv.client_count() > 0


@persistent
def on_depsgraph_update(scene, depsgraph):
    global _last_selection
    connected = _clients_connected()

    # Selection diff (cheap, always on)
    selection = serializer.selected_names()
    if selection != _last_selection:
        _last_selection = selection
        if connected:
            commands.broadcast_selection()

    for update in depsgraph.updates:
        obj = update.id
        if not isinstance(obj, bpy.types.Object):
            if isinstance(obj, (bpy.types.Mesh, bpy.types.Material,
                                bpy.types.Image, bpy.types.NodeTree,
                                bpy.types.Texture)):
                _pending["geometry_dirty"] = True
            continue
        if obj.type not in {"MESH", "LIGHT", "CAMERA"}:
            continue
        if update.is_updated_geometry:
            _pending["geometry_dirty"] = True
        elif update.is_updated_transform:
            _pending["transform_names"].add(obj.name)

    if _pending["geometry_dirty"] or _pending["transform_names"]:
        commands.invalidate_snapshot_cache()
        if not connected or not commands.state["live_sync"]:
            _pending["transform_names"].clear()
            _pending["geometry_dirty"] = False
            return
        _pending["last_change"] = time.monotonic()
        _schedule_flush()


@persistent
def on_frame_change(scene, depsgraph=None):
    if not _clients_connected() or not commands.state["live_sync"]:
        return
    # Frame scrub: animated transforms move; geometry may deform too.
    # Cheap heuristic: mark all mesh/light/camera transforms pending.
    for obj in scene.objects:
        if obj.type in {"MESH", "LIGHT", "CAMERA"}:
            _pending["transform_names"].add(obj.name)
    _pending["last_change"] = time.monotonic()
    _schedule_flush()


def _schedule_flush():
    if _pending["timer_scheduled"]:
        return
    _pending["timer_scheduled"] = True
    bpy.app.timers.register(_flush, first_interval=DEBOUNCE_SECONDS)


def _flush():
    # Still being edited? Re-arm until the scene sits still for one window.
    since = time.monotonic() - _pending["last_change"]
    if since < DEBOUNCE_SECONDS:
        return DEBOUNCE_SECONDS - since
    _pending["timer_scheduled"] = False

    if not _clients_connected():
        _pending["transform_names"].clear()
        _pending["geometry_dirty"] = False
        return None

    if _pending["geometry_dirty"]:
        commands.send_snapshot()  # broadcast full scene
    elif _pending["transform_names"]:
        commands.broadcast_transforms(sorted(_pending["transform_names"]))
    _pending["transform_names"].clear()
    _pending["geometry_dirty"] = False
    return None


@persistent
def on_load_pre(*args):
    """New file loading — the old scene's objects are about to vanish."""
    _pending["transform_names"].clear()
    _pending["geometry_dirty"] = False
    commands.invalidate_snapshot_cache()
    serializer.clear_texture_caches()


@persistent
def on_load_post(*args):
    """Server survives file load; phones get the new scene."""
    global _last_selection
    _last_selection = []
    commands.invalidate_snapshot_cache()
    serializer.clear_texture_caches()
    if _clients_connected():
        commands.send_snapshot()


def register():
    for handler_list, fn in (
        (bpy.app.handlers.depsgraph_update_post, on_depsgraph_update),
        (bpy.app.handlers.frame_change_post, on_frame_change),
        (bpy.app.handlers.load_pre, on_load_pre),
        (bpy.app.handlers.load_post, on_load_post),
    ):
        if fn not in handler_list:
            handler_list.append(fn)


def unregister():
    for handler_list, fn in (
        (bpy.app.handlers.depsgraph_update_post, on_depsgraph_update),
        (bpy.app.handlers.frame_change_post, on_frame_change),
        (bpy.app.handlers.load_pre, on_load_pre),
        (bpy.app.handlers.load_post, on_load_post),
    ):
        if fn in handler_list:
            handler_list.remove(fn)
    if bpy.app.timers.is_registered(_flush):
        bpy.app.timers.unregister(_flush)
    _pending["timer_scheduled"] = False
    _pending["transform_names"].clear()
    _pending["geometry_dirty"] = False
