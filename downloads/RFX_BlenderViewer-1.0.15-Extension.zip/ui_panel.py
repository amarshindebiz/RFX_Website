# SPDX-License-Identifier: GPL-3.0-or-later
"""
N-panel UI (3D viewport sidebar, category "Blender Viewer").
"""

import os
import tempfile

import bpy
import bpy.utils.previews

from . import commands, qr

_previews = None
_qr_key_loaded = None  # "ip:port" currently rendered into the preview
_classes_registered = False


def _addon_preferences(context):
    """Return this package's saved preferences in legacy and extension installs."""
    addon = context.preferences.addons.get(__package__)
    return addon.preferences if addon is not None else None


def _display_address(server, hide_ip=False):
    """Return visible address text without changing the real server endpoint."""
    host = "****" if hide_ip else server.ip
    return f"{host}:{server.port}"


def _qr_icon_value():
    """Lazy-render the QR for the current server address into a preview."""
    global _previews, _qr_key_loaded
    srv = commands.get_server()
    if srv is None:
        return None
    key = f"{srv.ip}:{srv.port}"
    if _previews is None:
        _previews = bpy.utils.previews.new()
    if _qr_key_loaded != key:
        path = os.path.join(
            tempfile.gettempdir(), "blender_viewer_qr.png"
        )
        matrix = qr.qr_matrix(f"bv://{key}")
        qr.write_png(matrix, path, scale=8, border=2)
        if "qr" in _previews:
            del _previews["qr"]
        _previews.load("qr", path, "IMAGE")
        _qr_key_loaded = key
    return _previews["qr"].icon_id


# ---------------------------------------------------------------------------
# Properties (session-scoped → WindowManager)
# ---------------------------------------------------------------------------

def _live_sync_update(self, context):
    commands.state["live_sync"] = self.bv_live_sync


def _selected_only_update(self, context):
    commands.state["selected_only"] = self.bv_selected_only
    commands.invalidate_snapshot_cache()


def _allow_source_downloads_update(self, context):
    commands.set_allow_source_downloads(self.allow_source_downloads)


def _define_props():
    wm = bpy.types.WindowManager
    wm.bv_port = bpy.props.IntProperty(
        name="Port", default=commands.DEFAULT_PORT, min=1024, max=65535,
        description="WebSocket port the iPhone app connects to",
    )
    wm.bv_live_sync = bpy.props.BoolProperty(
        name="Live Sync", default=True,
        description="Stream edits to connected phones as you work",
        update=_live_sync_update,
    )
    wm.bv_selected_only = bpy.props.BoolProperty(
        name="Selected Only", default=False,
        description="Send only selected objects (cameras always included)",
        update=_selected_only_update,
    )


def _remove_props():
    wm = bpy.types.WindowManager
    for name in ("bv_port", "bv_live_sync", "bv_selected_only"):
        if hasattr(wm, name):
            delattr(wm, name)


# ---------------------------------------------------------------------------
# Operators
# ---------------------------------------------------------------------------

class BV_AddonPreferences(bpy.types.AddonPreferences):
    bl_idname = __package__

    hide_ip: bpy.props.BoolProperty(
        name="Hide IP address",
        default=False,
        description="Mask the IP address shown in the Blender Viewer panel",
    )
    hide_qr: bpy.props.BoolProperty(
        name="Hide QR code",
        default=False,
        description="Hide the connection QR code in the Blender Viewer panel",
    )
    allow_source_downloads: bpy.props.BoolProperty(
        name="Allow .blend downloads",
        default=False,
        description="Allow connected phones to save a copy of the current .blend file",
        update=_allow_source_downloads_update,
    )

    def draw(self, context):
        self.layout.prop(self, "hide_ip", icon="HIDE_ON")
        self.layout.prop(self, "hide_qr", icon="HIDE_ON")
        self.layout.prop(self, "allow_source_downloads", icon="FILE_BLEND")

class BV_OT_start_server(bpy.types.Operator):
    bl_idname = "blender_viewer.start_server"
    bl_label = "Start Server"
    bl_description = "Start the Blender Viewer WebSocket server"

    def execute(self, context):
        try:
            srv = commands.start_server(port=context.window_manager.bv_port)
        except OSError as exc:
            self.report({"ERROR"}, f"Could not start server: {exc}")
            return {"CANCELLED"}
        prefs = _addon_preferences(context)
        hide_ip = bool(prefs and prefs.hide_ip)
        self.report(
            {"INFO"},
            f"Blender Viewer serving on {_display_address(srv, hide_ip)}",
        )
        return {"FINISHED"}


class BV_OT_stop_server(bpy.types.Operator):
    bl_idname = "blender_viewer.stop_server"
    bl_label = "Stop Server"
    bl_description = "Stop the Blender Viewer server and disconnect phones"

    def execute(self, context):
        commands.stop_server()
        return {"FINISHED"}


class BV_OT_send_snapshot(bpy.types.Operator):
    bl_idname = "blender_viewer.send_snapshot"
    bl_label = "Send Snapshot"
    bl_description = "Send the full scene to all connected phones now"

    @classmethod
    def poll(cls, context):
        return commands.server_running()

    def execute(self, context):
        commands.send_snapshot()
        return {"FINISHED"}


class BV_OT_copy_address(bpy.types.Operator):
    bl_idname = "blender_viewer.copy_address"
    bl_label = "Copy Address"
    bl_description = "Copy the server address to the clipboard"

    @classmethod
    def poll(cls, context):
        return commands.server_running()

    def execute(self, context):
        srv = commands.get_server()
        context.window_manager.clipboard = f"{srv.ip}:{srv.port}"
        self.report({"INFO"}, "Address copied")
        return {"FINISHED"}


# ---------------------------------------------------------------------------
# Panel
# ---------------------------------------------------------------------------

class BV_PT_main(bpy.types.Panel):
    bl_label = "Blender Viewer"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Blender Viewer"

    def draw(self, context):
        layout = self.layout
        wm = context.window_manager
        running = commands.server_running()
        prefs = _addon_preferences(context)
        hide_ip = bool(prefs and prefs.hide_ip)
        hide_qr = bool(prefs and prefs.hide_qr)
        allow_source = bool(prefs and prefs.allow_source_downloads)
        commands.state["allow_source_downloads"] = allow_source

        row = layout.row(align=True)
        if running:
            row.operator("blender_viewer.stop_server",
                         text="Stop Server", icon="PAUSE")
        else:
            row.operator("blender_viewer.start_server",
                         text="Start Server", icon="PLAY")

        if prefs is not None:
            privacy_row = layout.row(align=True)
            privacy_row.prop(
                prefs,
                "hide_ip",
                text="Hide IP",
                icon="HIDE_ON" if hide_ip else "HIDE_OFF",
            )
            privacy_row.prop(
                prefs,
                "hide_qr",
                text="Hide QR",
                icon="HIDE_ON" if hide_qr else "HIDE_OFF",
            )

        status = layout.row()
        if running:
            srv = commands.get_server()
            status.label(
                text=f"● {_display_address(srv, hide_ip)}", icon="CHECKMARK",
            )
            n = commands.state["client_count"]
            layout.label(
                text=f"{n} phone{'s' if n != 1 else ''} connected",
                icon="OUTLINER_OB_POINTCLOUD" if n else "BLANK1",
            )
            layout.operator("blender_viewer.copy_address", icon="COPYDOWN")

            icon_value = None
            if not hide_qr:
                try:
                    icon_value = _qr_icon_value()
                except Exception:
                    pass  # QR is a nicety; the panel must never break
            if icon_value:
                box = layout.box()
                box.label(text="Scan with Blender Viewer app:")
                box.template_icon(icon_value=icon_value, scale=6.0)
        else:
            status.label(text="Server stopped", icon="X")
            layout.prop(wm, "bv_port")

        layout.separator()
        layout.prop(wm, "bv_live_sync", icon="UV_SYNC_SELECT")
        layout.prop(wm, "bv_selected_only", icon="RESTRICT_SELECT_OFF")
        if prefs is not None:
            layout.prop(
                prefs,
                "allow_source_downloads",
                text="Allow .blend Downloads",
                icon="FILE_BLEND",
            )
        layout.operator("blender_viewer.send_snapshot", icon="EXPORT")


CLASSES = (
    BV_AddonPreferences,
    BV_OT_start_server,
    BV_OT_stop_server,
    BV_OT_send_snapshot,
    BV_OT_copy_address,
    BV_PT_main,
)


def register():
    global _classes_registered
    if _classes_registered:
        return
    _define_props()
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    prefs = _addon_preferences(bpy.context)
    commands.state["allow_source_downloads"] = bool(
        prefs and prefs.allow_source_downloads
    )
    _classes_registered = True


def unregister():
    global _previews, _qr_key_loaded, _classes_registered
    if not _classes_registered:
        return
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
    _classes_registered = False
    _remove_props()
    if _previews is not None:
        bpy.utils.previews.remove(_previews)
        _previews = None
        _qr_key_loaded = None
