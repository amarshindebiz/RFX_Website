# SPDX-License-Identifier: GPL-3.0-or-later
"""
Tiny pure-python QR encoder — byte mode, error correction level L,
versions 1-5 (plenty for "bv://192.168.255.255:65535"). Stdlib only.

Public API:
    matrix = qr_matrix("bv://192.168.1.23:9010")   # list[list[bool]]
    write_png(matrix, "/tmp/qr.png", scale=8, border=4)
"""

import struct
import zlib

# (data codewords, ec codewords) per version at ECC level L — all single-block
_CAPACITY = {1: (19, 7), 2: (34, 10), 3: (55, 15), 4: (80, 20), 5: (108, 26)}
_ALIGNMENT = {1: [], 2: [6, 18], 3: [6, 22], 4: [6, 26], 5: [6, 30]}

# --- GF(256) arithmetic for Reed-Solomon -----------------------------------

_EXP = [0] * 512
_LOG = [0] * 256
_x = 1
for _i in range(255):
    _EXP[_i] = _x
    _LOG[_x] = _i
    _x <<= 1
    if _x & 0x100:
        _x ^= 0x11D
for _i in range(255, 512):
    _EXP[_i] = _EXP[_i - 255]


def _gf_mul(a, b):
    if a == 0 or b == 0:
        return 0
    return _EXP[_LOG[a] + _LOG[b]]


def _rs_generator(n):
    g = [1]
    for i in range(n):
        g = _poly_mul(g, [1, _EXP[i]])
    return g


def _poly_mul(p, q):
    out = [0] * (len(p) + len(q) - 1)
    for i, pi in enumerate(p):
        for j, qj in enumerate(q):
            out[i + j] ^= _gf_mul(pi, qj)
    return out


def _rs_encode(data, n_ec):
    gen = _rs_generator(n_ec)
    rem = list(data) + [0] * n_ec
    for i in range(len(data)):
        factor = rem[i]
        if factor:
            for j in range(1, len(gen)):
                rem[i + j] ^= _gf_mul(gen[j], factor)
    return rem[len(data):]


# --- bit packing -------------------------------------------------------------

def _make_codewords(payload, version):
    n_data, n_ec = _CAPACITY[version]
    bits = []

    def put(value, length):
        for i in range(length - 1, -1, -1):
            bits.append((value >> i) & 1)

    put(0b0100, 4)               # byte mode
    put(len(payload), 8)         # char count (8 bits, versions 1-9)
    for b in payload:
        put(b, 8)
    # terminator
    put(0, min(4, n_data * 8 - len(bits)))
    while len(bits) % 8:
        bits.append(0)
    data = bytearray()
    for i in range(0, len(bits), 8):
        byte = 0
        for bit in bits[i:i + 8]:
            byte = (byte << 1) | bit
        data.append(byte)
    # pad codewords
    pads = (0xEC, 0x11)
    i = 0
    while len(data) < n_data:
        data.append(pads[i % 2])
        i += 1
    return bytes(data) + bytes(_rs_encode(data, n_ec))


# --- matrix construction ------------------------------------------------------

def _place_function_patterns(size, version):
    """Returns (modules, reserved) — reserved marks non-data cells."""
    modules = [[False] * size for _ in range(size)]
    reserved = [[False] * size for _ in range(size)]

    def set_module(r, c, v):
        modules[r][c] = v
        reserved[r][c] = True

    def finder(r0, c0):
        for r in range(-1, 8):
            for c in range(-1, 8):
                rr, cc = r0 + r, c0 + c
                if 0 <= rr < size and 0 <= cc < size:
                    inside = 0 <= r <= 6 and 0 <= c <= 6
                    ring = inside and (r in (0, 6) or c in (0, 6))
                    core = 2 <= r <= 4 and 2 <= c <= 4
                    set_module(rr, cc, bool(ring or core))

    finder(0, 0)
    finder(0, size - 7)
    finder(size - 7, 0)

    # timing
    for i in range(8, size - 8):
        v = i % 2 == 0
        if not reserved[6][i]:
            set_module(6, i, v)
        if not reserved[i][6]:
            set_module(i, 6, v)

    # alignment
    centers = _ALIGNMENT[version]
    for r0 in centers:
        for c0 in centers:
            if reserved[r0][c0]:
                continue  # overlaps a finder
            for r in range(-2, 3):
                for c in range(-2, 3):
                    set_module(r0 + r, c0 + c,
                               max(abs(r), abs(c)) != 1)

    # format info areas (values filled later)
    for i in range(9):
        if not reserved[8][i]:
            set_module(8, i, False)
        if not reserved[i][8]:
            set_module(i, 8, False)
    for i in range(8):
        if not reserved[8][size - 1 - i]:
            set_module(8, size - 1 - i, False)
        if not reserved[size - 1 - i][8]:
            set_module(size - 1 - i, 8, False)
    set_module(size - 8, 8, True)  # dark module

    return modules, reserved


def _place_data(modules, reserved, codewords):
    size = len(modules)
    bit_index = 0
    total_bits = len(codewords) * 8
    col = size - 1
    upward = True
    while col > 0:
        if col == 6:
            col -= 1  # skip timing column
        rows = range(size - 1, -1, -1) if upward else range(size)
        for row in rows:
            for c in (col, col - 1):
                if reserved[row][c]:
                    continue
                if bit_index < total_bits:
                    byte = codewords[bit_index >> 3]
                    modules[row][c] = bool((byte >> (7 - (bit_index & 7))) & 1)
                    bit_index += 1
                # remainder bits stay False
        upward = not upward
        col -= 2


_MASKS = [
    lambda r, c: (r + c) % 2 == 0,
    lambda r, c: r % 2 == 0,
    lambda r, c: c % 3 == 0,
    lambda r, c: (r + c) % 3 == 0,
    lambda r, c: (r // 2 + c // 3) % 2 == 0,
    lambda r, c: (r * c) % 2 + (r * c) % 3 == 0,
    lambda r, c: ((r * c) % 2 + (r * c) % 3) % 2 == 0,
    lambda r, c: ((r + c) % 2 + (r * c) % 3) % 2 == 0,
]


def _apply_mask(modules, reserved, mask_fn):
    size = len(modules)
    out = [row[:] for row in modules]
    for r in range(size):
        for c in range(size):
            if not reserved[r][c] and mask_fn(r, c):
                out[r][c] = not out[r][c]
    return out


def _format_bits(mask):
    fmt = (0b01 << 3) | mask  # ECC L = 01
    rem = fmt << 10
    gen = 0b10100110111
    for i in range(14, 9, -1):
        if rem >> i & 1:
            rem ^= gen << (i - 10)
    return ((fmt << 10) | rem) ^ 0b101010000010010


def _write_format(modules, mask):
    size = len(modules)
    bits = _format_bits(mask)

    def bit(i):
        return bool((bits >> i) & 1)

    # around top-left finder
    coords_a = [(8, 0), (8, 1), (8, 2), (8, 3), (8, 4), (8, 5), (8, 7), (8, 8),
                (7, 8), (5, 8), (4, 8), (3, 8), (2, 8), (1, 8), (0, 8)]
    # split between bottom-left and top-right
    coords_b = [(size - 1, 8), (size - 2, 8), (size - 3, 8), (size - 4, 8),
                (size - 5, 8), (size - 6, 8), (size - 7, 8),
                (8, size - 8), (8, size - 7), (8, size - 6), (8, size - 5),
                (8, size - 4), (8, size - 3), (8, size - 2), (8, size - 1)]
    for i, (r, c) in enumerate(coords_a):
        modules[r][c] = bit(14 - i)
    for i, (r, c) in enumerate(coords_b):
        modules[r][c] = bit(14 - i)


def _penalty(modules):
    size = len(modules)
    score = 0
    # N1: runs of 5+ same-color in row/col
    for lines in (modules, list(zip(*modules))):
        for line in lines:
            run = 1
            for i in range(1, size):
                if line[i] == line[i - 1]:
                    run += 1
                else:
                    if run >= 5:
                        score += 3 + (run - 5)
                    run = 1
            if run >= 5:
                score += 3 + (run - 5)
    # N2: 2x2 blocks
    for r in range(size - 1):
        for c in range(size - 1):
            v = modules[r][c]
            if v == modules[r][c + 1] == modules[r + 1][c] == modules[r + 1][c + 1]:
                score += 3
    # N3: finder-like patterns
    pattern = [True, False, True, True, True, False, True]
    for lines in (modules, list(zip(*modules))):
        for line in lines:
            line = list(line)
            for i in range(size - 6):
                if line[i:i + 7] == pattern:
                    before = line[max(0, i - 4):i]
                    after = line[i + 7:i + 11]
                    if (len(before) == 4 and not any(before)) or \
                       (len(after) == 4 and not any(after)):
                        score += 40
    # N4: dark ratio
    dark = sum(sum(row) for row in modules)
    percent = dark * 100 // (size * size)
    score += (abs(percent - 50) // 5) * 10
    return score


def qr_matrix(text):
    payload = text.encode("utf-8")
    version = None
    for v, (n_data, _) in sorted(_CAPACITY.items()):
        if len(payload) + 2 <= n_data:  # 4-bit mode + 8-bit count ≈ 2 bytes
            version = v
            break
    if version is None:
        raise ValueError("payload too long for QR versions 1-5 at ECC L")

    size = 17 + version * 4
    codewords = _make_codewords(payload, version)
    modules, reserved = _place_function_patterns(size, version)
    _place_data(modules, reserved, codewords)

    best = None
    best_score = None
    for mask in range(8):
        candidate = _apply_mask(modules, reserved, _MASKS[mask])
        _write_format(candidate, mask)
        score = _penalty(candidate)
        if best_score is None or score < best_score:
            best, best_score = candidate, score
    return best


def write_png(matrix, path, scale=8, border=4):
    """Minimal grayscale PNG writer (stdlib zlib/struct only)."""
    n = len(matrix)
    dim = (n + border * 2) * scale
    rows = []
    for py in range(dim):
        my = py // scale - border
        row = bytearray([0])  # filter type 0
        for px in range(dim):
            mx = px // scale - border
            dark = 0 <= my < n and 0 <= mx < n and matrix[my][mx]
            row.append(0 if dark else 255)
        rows.append(bytes(row))
    raw = zlib.compress(b"".join(rows), 9)

    def chunk(tag, data):
        block = tag + data
        return struct.pack(">I", len(data)) + block + \
            struct.pack(">I", zlib.crc32(block) & 0xFFFFFFFF)

    ihdr = struct.pack(">IIBBBBB", dim, dim, 8, 0, 0, 0, 0)  # 8-bit gray
    with open(path, "wb") as f:
        f.write(b"\x89PNG\r\n\x1a\n")
        f.write(chunk(b"IHDR", ihdr))
        f.write(chunk(b"IDAT", raw))
        f.write(chunk(b"IEND", b""))
