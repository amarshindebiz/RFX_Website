# SPDX-License-Identifier: GPL-3.0-or-later
"""
Server state + incoming command dispatch. All functions here run on
Blender's MAIN thread (marshaled via server.main_thread_queue), so bpy
access is safe.
"""

import math

import bpy
from mathutils import Matrix, Quaternion, Vector

from . import serializer
from .server import ViewerServer


def _finite_floats(values, count):
    """Coerce a client-supplied numeric list to exactly `count` finite floats.

    Rejects NaN / +-Infinity and wrong shapes with ValueError. A NaN/Inf that
    reaches obj.matrix_world silently poisons the object and makes EVERY later
    snapshot fail with a singular-matrix error, so this guard runs before any
    bpy write.
    """
    if not isinstance(values, (list, tuple)) or len(values) != count:
        raise ValueError(f"expected {count} numbers, got {values!r}")
    out = []
    for v in values:
        if isinstance(v, bool) or not isinstance(v, (int, float)):
            raise ValueError(f"non-numeric component: {v!r}")
        f = float(v)
        if not math.isfinite(f):
            raise ValueError(f"non-finite component: {v!r}")
        out.append(f)
    return out


ADDON_VERSION = "1.0.7"
DEFAULT_PORT = 9010

# Module-level state (single server per Blender instance)
state = {
    "server": None,       # ViewerServer | None
    "live_sync": True,
    "selected_only": False,
    "client_count": 0,
}


def server_running():
    srv = state["server"]
    return srv is not None and srv.running


def get_server():
    return state["server"]


# ---------------------------------------------------------------------------
# Lifecycle
# ---------------------------------------------------------------------------

def start_server(port=DEFAULT_PORT):
    if server_running():
        return state["server"]
    srv = ViewerServer(port=port)
    srv.on_message = dispatch
    srv.on_client_ready = _on_client_ready
    srv.on_clients_changed = _on_clients_changed
    srv.start()
    state["server"] = srv
    print(f"[Blender Viewer] server listening on {srv.ip}:{srv.port}")
    return srv


def stop_server():
    srv = state["server"]
    if srv is not None:
        srv.stop()
        state["server"] = None
        state["client_count"] = 0
        print("[Blender Viewer] server stopped")


def _on_clients_changed(count):
    state["client_count"] = count
    _redraw_panels()


def _on_client_ready(client):
    client.send_json({
        "type": "hello",
        "protocol": serializer.PROTOCOL_VERSION,
        "app": "blender_addon",
        "version": ADDON_VERSION,
        "blender": bpy.app.version_string,
    })
    _redraw_panels()


def _redraw_panels():
    wm = bpy.context.window_manager
    if wm is None:
        return
    for window in wm.windows:
        for area in window.screen.areas:
            if area.type == "VIEW_3D":
                area.tag_redraw()


# ---------------------------------------------------------------------------
# Outgoing
# ---------------------------------------------------------------------------

def send_snapshot(client=None):
    """Full scene → one client, or broadcast when client is None."""
    srv = state["server"]
    if srv is None:
        return
    if client is None:
        # Per-client texture caches make a broadcast snapshot a set of
        # targeted snapshots; reconnecting clients must not inherit another
        # phone's cache state.
        with srv._clients_lock:
            clients = list(srv.clients)
        for connected_client in clients:
            send_snapshot(connected_client)
        return

    # A large textured scene can spend several seconds encoding images before
    # scene_begin exists. Tell the app this is active work, not an empty scene.
    if not client.send_json({
        "type": "snapshot_status",
        "phase": "preparing",
        "message": "Preparing Blender scene…",
    }):
        return

    textures = serializer.collect_textures(
        selected_only=state["selected_only"]
    )
    if not client.send_json({
        "type": "snapshot_status",
        "phase": "streaming",
        "message": "Streaming geometry…",
    }):
        return
    pending = [item for key, item in textures.items()
               if key not in client.sent_texture_ids]
    if pending:
        if not client.send_json({
            "type": "texture_manifest",
            "textures": [{k: v for k, v in item.items() if k != "frame"}
                         for item in pending],
        }):
            return
        for item in pending:
            if not client.send_binary(item["frame"]):
                return
            client.sent_texture_ids.add(item["id"])

    for message in serializer.snapshot_messages(
        selected_only=state["selected_only"]
    ):
        if not client.send_json(message):
            return


def broadcast_selection():
    srv = state["server"]
    if srv is not None:
        srv.broadcast_json({
            "type": "selection_update",
            "selected": serializer.selected_names(),
        })


def broadcast_transforms(names):
    srv = state["server"]
    if srv is not None and names:
        srv.broadcast_json(serializer.transform_update_message(names))


def broadcast_scene_transforms():
    """Refresh every transform after Blender history navigation.

    This stays lightweight even for dense scenes and is sufficient for the
    transform-only Undo/Redo commands exposed by the phone.
    """
    names = [obj.name for obj in bpy.context.scene.objects
             if obj.type in {"MESH", "LIGHT", "CAMERA"}]
    broadcast_transforms(names)


# ---------------------------------------------------------------------------
# Incoming dispatch (main thread)
# ---------------------------------------------------------------------------

def dispatch(client, message):
    mtype = message.get("type")
    if mtype == "hello":
        _cmd_hello(client, message)
    elif mtype == "command":
        cmd = message.get("command")
        handler = _COMMANDS.get(cmd)
        if handler is None:
            client.send_json({
                "type": "error", "message": f"unknown command: {cmd}",
            })
        else:
            try:
                handler(client, message)
            except Exception as exc:
                client.send_json({
                    "type": "error", "code": "command_failed",
                    "message": f"Command failed: {type(exc).__name__}",
                })
    else:
        client.send_json({
            "type": "error", "message": f"unknown message type: {mtype}",
        })


def _cmd_hello(client, message):
    their_protocol = message.get("protocol")
    if their_protocol != serializer.PROTOCOL_VERSION:
        client.send_json({
            "type": "error",
            "code": "protocol_mismatch",
            "message": (
                f"Protocol mismatch (add-on {serializer.PROTOCOL_VERSION}, "
                f"app {their_protocol}). Update the add-on / app."
            ),
        })
        return
    # Handshake complete → give the phone the scene right away.
    send_snapshot(client)


def _cmd_snapshot(client, message):
    send_snapshot(client)


def _cmd_set_live_sync(client, message):
    enabled = message.get("enabled", True)
    if not isinstance(enabled, bool):
        client.send_json({
            "type": "ack", "command": "set_live_sync",
            "status": "bad_payload", "detail": "enabled must be boolean",
        })
        return
    state["live_sync"] = enabled
    client.send_json({
        "type": "ack", "command": "set_live_sync",
        "enabled": state["live_sync"], "status": "ok",
    })
    _redraw_panels()


def _cmd_select_object(client, message):
    name = message.get("name")
    if name is not None and not isinstance(name, str):
        client.send_json({
            "type": "ack", "command": "select_object",
            "status": "bad_payload", "detail": "name must be string or null",
        })
        return
    obj = bpy.context.scene.objects.get(name) if name else None
    view_layer = bpy.context.view_layer
    for other in bpy.context.selected_objects:
        other.select_set(False)
    if obj is not None:
        obj.select_set(True)
        view_layer.objects.active = obj
    client.send_json({
        "type": "ack", "command": "select_object",
        "name": name, "status": "ok" if obj or name is None else "not_found",
    })
    broadcast_selection()


def _ios_transform_to_world(location, rotation_quat, scale):
    """iOS-space loc/quat(xyzw)/scale → Blender world matrix (inverse of
    serializer.convert_matrix). Validates every component is finite and the
    scale is non-degenerate before building the matrix."""
    loc = _finite_floats(location, 3)
    q = _finite_floats(rotation_quat, 4)
    s = _finite_floats(scale, 3)
    if any(abs(component) < 1e-9 for component in s):
        raise ValueError(f"degenerate (near-zero) scale: {scale!r}")
    quat = Quaternion((q[3], q[0], q[1], q[2]))  # mathutils wants wxyz
    if quat.magnitude < 1e-9:
        raise ValueError("zero-length rotation quaternion")
    m = Matrix.LocRotScale(Vector(loc), quat, Vector(s))
    return serializer._C4_INV @ m @ serializer._C4


def _cmd_set_transform(client, message):
    name = message.get("name")
    obj = bpy.context.scene.objects.get(name) if name else None
    if obj is None:
        client.send_json({
            "type": "ack", "command": "set_transform",
            "name": name, "status": "not_found",
        })
        return
    try:
        obj.matrix_world = _ios_transform_to_world(
            message["location"], message["rotation"], message["scale"],
        )
    except (KeyError, TypeError, ValueError) as exc:
        client.send_json({
            "type": "ack", "command": "set_transform",
            "name": name, "status": "bad_payload", "detail": str(exc),
        })
        return
    # Phone edits must be Ctrl+Z-able in Blender.
    bpy.ops.ed.undo_push(message=f"Blender Viewer: move {name}")
    client.send_json({
        "type": "ack", "command": "set_transform",
        "name": name, "status": "ok",
    })


def _run_history_command(client, command, operator):
    """Run Blender's native history and immediately refresh phone transforms."""
    try:
        result = operator()
        status = "ok" if "FINISHED" in result else "unavailable"
    except RuntimeError as exc:
        client.send_json({
            "type": "ack", "command": command,
            "status": "unavailable", "detail": str(exc),
        })
        return

    client.send_json({
        "type": "ack", "command": command, "status": status,
    })
    if status == "ok":
        bpy.context.view_layer.update()
        broadcast_scene_transforms()
        broadcast_selection()


def _cmd_undo(client, message):
    _run_history_command(client, "undo", bpy.ops.ed.undo)


def _cmd_redo(client, message):
    _run_history_command(client, "redo", bpy.ops.ed.redo)


_COMMANDS = {
    "snapshot": _cmd_snapshot,
    "set_live_sync": _cmd_set_live_sync,
    "select_object": _cmd_select_object,
    "set_transform": _cmd_set_transform,
    "undo": _cmd_undo,
    "redo": _cmd_redo,
}
