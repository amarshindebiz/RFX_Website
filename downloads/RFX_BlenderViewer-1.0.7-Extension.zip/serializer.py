# SPDX-License-Identifier: GPL-3.0-or-later
"""
Scene → protocol payloads. MAIN THREAD ONLY (touches bpy everywhere).

Protocol 1 geometry is JSON flat arrays (Maya Viewer parity); the message
shape is kept flat so a binary fast path can replace the arrays in v1.1.

Coordinate system: Blender is Z-up right-handed, SceneKit/RealityKit are
Y-up right-handed. ALL positions/normals/transforms are converted HERE,
before sending: (x, y, z) → (x, z, -y). The iOS side is conversion-free.
"""

import hashlib
import math
import os
import struct
import tempfile
from collections import OrderedDict

import bpy
import numpy as np
from mathutils import Matrix

PROTOCOL_VERSION = 1

# Change of basis Z-up → Y-up. Proper rotation (det = +1), so converted
# matrices still decompose into clean loc/quat/scale.
_C = Matrix(((1.0, 0.0, 0.0), (0.0, 0.0, 1.0), (0.0, -1.0, 0.0)))
_C4 = _C.to_4x4()
_C4_INV = _C4.inverted()

_FLOAT_DECIMALS = 5


def _rounded(seq):
    return [round(float(v), _FLOAT_DECIMALS) for v in seq]


def _swizzle_np(arr):
    """(N,3) Blender-space → (N,3) iOS-space: (x, y, z) → (x, z, -y)."""
    out = np.empty_like(arr)
    out[:, 0] = arr[:, 0]
    out[:, 1] = arr[:, 2]
    out[:, 2] = -arr[:, 1]
    return out


def convert_matrix(matrix_world):
    """Blender world matrix → iOS-space loc / quaternion / scale dict.

    Conjugation (C·M·C⁻¹) — the transform as a mapping of POINTS in the new
    basis. Use for object transforms: the iOS side applies deltas
    (M_new · M_base⁻¹) to world-space-baked vertices, and conjugated deltas
    move points exactly right.
    """
    m = _C4 @ matrix_world @ _C4_INV
    loc, quat, scale = m.decompose()
    return {
        "location": _rounded(loc),
        "rotation_quat": _rounded([quat.x, quat.y, quat.z, quat.w]),
        "scale": _rounded(scale),
    }


def convert_matrix_oriented(matrix_world):
    """Blender world matrix → iOS transform for CAMERAS and LIGHTS: C·M
    (no right factor).

    Cameras and directional lights render along their LOCAL -Z in both
    Blender and SceneKit. Conjugation relabels the local frame — the node's
    -Z would end up aiming along Blender's local +Y (the camera's up), which
    pointed every Blender camera 90° off and gave a blank viewport. With
    R' = C·R each local axis maps through C directly: forward stays forward,
    up stays up.
    """
    m = _C4 @ matrix_world
    loc, quat, scale = m.decompose()
    return {
        "location": _rounded(loc),
        "rotation_quat": _rounded([quat.x, quat.y, quat.z, quat.w]),
        "scale": _rounded(scale),
    }


# ---------------------------------------------------------------------------
# Meshes
# ---------------------------------------------------------------------------

def _mesh_payload(obj, depsgraph):
    """Evaluated mesh (modifiers/geo-nodes baked) → geometry arrays.

    Vertices are expanded per loop corner so split normals shade correctly.
    A separate compact vertex array + original edge list drives the quad/ngon
    wireframe (never triangulated diagonals).
    """
    eval_obj = obj.evaluated_get(depsgraph)
    try:
        mesh = eval_obj.to_mesh()
    except RuntimeError:
        return None
    try:
        mesh.calc_loop_triangles()

        n_verts = len(mesh.vertices)
        n_loops = len(mesh.loops)
        n_tris = len(mesh.loop_triangles)
        if n_verts == 0 or n_tris == 0:
            return None

        mw = np.array(obj.matrix_world, dtype=np.float64)

        # Original vertices → world space
        co = np.empty(n_verts * 3, dtype=np.float64)
        mesh.vertices.foreach_get("co", co)
        co = co.reshape(n_verts, 3)
        co_world = co @ mw[:3, :3].T + mw[:3, 3]
        co_ios = _swizzle_np(co_world)

        # Per-corner expansion
        loop_vidx = np.empty(n_loops, dtype=np.int64)
        mesh.loops.foreach_get("vertex_index", loop_vidx)
        positions = co_ios[loop_vidx]

        # Corner normals (Blender 4.1+ replacement for calc_normals_split)
        normals = np.empty(n_loops * 3, dtype=np.float64)
        mesh.corner_normals.foreach_get("vector", normals)
        normals = normals.reshape(n_loops, 3)
        nrm_mat = np.linalg.inv(mw[:3, :3]).T
        normals = normals @ nrm_mat.T
        lengths = np.linalg.norm(normals, axis=1, keepdims=True)
        lengths[lengths == 0.0] = 1.0
        normals = _swizzle_np(normals / lengths)

        # Triangles index into the corner arrays
        tris = np.empty(n_tris * 3, dtype=np.int64)
        mesh.loop_triangles.foreach_get("loops", tris)

        tri_mat_index = np.empty(n_tris, dtype=np.int64)
        mesh.loop_triangles.foreach_get("material_index", tri_mat_index)

        # UVs (active layer), per corner. V flipped for SceneKit's texture space.
        uvs = None
        uv_layer = mesh.uv_layers.active
        if uv_layer is not None and len(uv_layer.data) == n_loops:
            uv = np.empty(n_loops * 2, dtype=np.float64)
            uv_layer.data.foreach_get("uv", uv)
            uv = uv.reshape(n_loops, 2)
            uv[:, 1] = 1.0 - uv[:, 1]
            uvs = uv

        # Original edges for wireframe (quads/ngons, not triangulation)
        n_edges = len(mesh.edges)
        wire_edges = np.empty(n_edges * 2, dtype=np.int64)
        mesh.edges.foreach_get("vertices", wire_edges)

        rnd = _FLOAT_DECIMALS
        payload = {
            "positions": np.round(positions.reshape(-1), rnd).tolist(),
            "normals": np.round(normals.reshape(-1), rnd).tolist(),
            "triangles": tris.tolist(),
            "triangle_material_index": tri_mat_index.tolist(),
            "wire_positions": np.round(co_ios.reshape(-1), rnd).tolist(),
            "wire_edges": wire_edges.tolist(),
            "stats": {
                "vertices": n_verts,
                "triangles": n_tris,
                "corners": n_loops,
                "edges": n_edges,
            },
        }
        if uvs is not None:
            payload["uvs"] = np.round(uvs.reshape(-1), rnd).tolist()
        return payload
    finally:
        eval_obj.to_mesh_clear()


# ---------------------------------------------------------------------------
# Materials / textures
# ---------------------------------------------------------------------------

_MAX_TEXTURE_SIZE = 2048
_MAX_TEXTURE_CACHE_BYTES = 256 * 1024 * 1024
_MAX_TEXTURE_CACHE_ITEMS = 128
_texture_cache = OrderedDict()  # hex id -> encoded PNG bytes (LRU)
_texture_cache_bytes = 0
_image_texture_ids = {}   # image pointer -> hex id for current contents
_file_texture_ids = {}    # (absolute path, mtime ns, size) -> hex id
_last_viewport_environment = None


def _cached_texture(texture_id):
    data = _texture_cache.get(texture_id)
    if data is not None:
        _texture_cache.move_to_end(texture_id)
    return data


def _store_texture(texture_id, data):
    """Bound encoded-image memory across long edit/snapshot sessions."""
    global _texture_cache_bytes
    previous = _texture_cache.pop(texture_id, None)
    if previous is not None:
        _texture_cache_bytes -= len(previous)
    _texture_cache[texture_id] = data
    _texture_cache_bytes += len(data)
    evicted = set()
    while (_texture_cache_bytes > _MAX_TEXTURE_CACHE_BYTES
           or len(_texture_cache) > _MAX_TEXTURE_CACHE_ITEMS):
        old_id, old_data = _texture_cache.popitem(last=False)
        _texture_cache_bytes -= len(old_data)
        evicted.add(old_id)
    if evicted:
        for mapping in (_image_texture_ids, _file_texture_ids):
            for key, value in list(mapping.items()):
                if value in evicted:
                    del mapping[key]

def _find_principled(mat):
    if not mat or not mat.use_nodes or not mat.node_tree:
        return None
    for node in mat.node_tree.nodes:
        if node.bl_idname == "ShaderNodeBsdfPrincipled":
            return node
    return None


def _input_value(node, *names):
    """First existing input by name — socket names drift between 4.x and 5.x."""
    for name in names:
        sock = node.inputs.get(name)
        if sock is not None:
            return sock
    return None


def _linked_image(socket):
    """Find the nearest Image Texture feeding a Principled input.

    Transparent utility nodes (normal color correction, Mix, etc.) are
    traversed breadth-first. This covers direct links and common authored
    node graphs without assuming node names.
    """
    if socket is None or not socket.is_linked:
        return None
    pending = [link.from_node for link in socket.links]
    seen = set()
    while pending:
        node = pending.pop(0)
        key = node.as_pointer()
        if key in seen:
            continue
        seen.add(key)
        if node.bl_idname == "ShaderNodeTexImage" and node.image is not None:
            return node.image
        for input_socket in node.inputs:
            pending.extend(link.from_node for link in input_socket.links)
    return None


def _linked_texture(socket):
    """Return (image, source channel) for a linked scalar/color socket.

    Principled workflows commonly pack roughness/metallic/AO into RGB.  The
    channel is determined from the first Separate Color/RGB output on the
    path, while still walking through utility nodes to the image itself.
    """
    if socket is None or not socket.is_linked:
        return None, None
    pending = [(link.from_node, link.from_socket.name) for link in socket.links]
    seen = set()
    while pending:
        node, channel = pending.pop(0)
        key = (node.as_pointer(), channel)
        if key in seen:
            continue
        seen.add(key)
        if node.bl_idname == "ShaderNodeTexImage" and node.image is not None:
            value = channel.lower()
            mapped = {"red": "red", "r": "red", "green": "green", "g": "green",
                      "blue": "blue", "b": "blue", "alpha": "alpha", "a": "alpha"}
            return node.image, mapped.get(value, "rgb")
        inherited = channel
        if node.bl_idname in {"ShaderNodeSeparateColor", "ShaderNodeSeparateRGB"}:
            inherited = channel
        for input_socket in node.inputs:
            for link in input_socket.links:
                pending.append((link.from_node, inherited))
    return None, None


def _linked_node(socket, node_type):
    if socket is None or not socket.is_linked:
        return None
    pending = [link.from_node for link in socket.links]
    seen = set()
    while pending:
        node = pending.pop(0)
        key = node.as_pointer()
        if key in seen:
            continue
        seen.add(key)
        if node.bl_idname == node_type:
            return node
        for input_socket in node.inputs:
            pending.extend(link.from_node for link in input_socket.links)
    return None


def _encode_image_png(image):
    """Return transport-safe PNG bytes, downscaled without mutating source."""
    copy = image.copy()
    fd, path = tempfile.mkstemp(prefix="blender-viewer-", suffix=".png")
    os.close(fd)
    try:
        width, height = copy.size
        longest = max(width, height)
        if longest > _MAX_TEXTURE_SIZE:
            ratio = _MAX_TEXTURE_SIZE / float(longest)
            copy.scale(max(1, round(width * ratio)), max(1, round(height * ratio)))
        copy.filepath_raw = path
        copy.file_format = "PNG"
        copy.save()
        with open(path, "rb") as handle:
            return handle.read()
    finally:
        try:
            bpy.data.images.remove(copy)
        except (ReferenceError, RuntimeError):
            pass
        try:
            os.unlink(path)
        except OSError:
            pass


def texture_for_image(image):
    """Encode/cache an image and return (hex id, binary frame)."""
    pointer = image.as_pointer()
    cached_id = _image_texture_ids.get(pointer)
    data = _cached_texture(cached_id)
    if data is not None and not image.is_dirty:
        raw_id = bytes.fromhex(cached_id)
        return cached_id, raw_id + struct.pack(">I", len(data)) + data

    file_key = None
    try:
        path = bpy.path.abspath(image.filepath, library=image.library)
        if path and os.path.isfile(path):
            stat = os.stat(path)
            file_key = (os.path.realpath(path), stat.st_mtime_ns, stat.st_size)
            cached_id = _file_texture_ids.get(file_key)
            data = _cached_texture(cached_id)
            if data is not None and not image.is_dirty:
                _image_texture_ids[pointer] = cached_id
                raw_id = bytes.fromhex(cached_id)
                return cached_id, raw_id + struct.pack(">I", len(data)) + data
    except (AttributeError, OSError, TypeError):
        pass

    data = _encode_image_png(image)
    raw_id = hashlib.sha256(data).digest()[:16]
    texture_id = raw_id.hex()
    _store_texture(texture_id, data)
    _image_texture_ids[pointer] = texture_id
    if file_key is not None:
        _file_texture_ids[file_key] = texture_id
    frame = raw_id + struct.pack(">I", len(data)) + data
    return texture_id, frame


def collect_textures(selected_only=False):
    """Encode PBR images and the active Material Preview environment."""
    global _last_viewport_environment
    textures = {}
    selected = set(selected_names()) if selected_only else None
    for obj in bpy.context.scene.objects:
        if obj.type != "MESH" or not obj.visible_get():
            continue
        if selected is not None and obj.name not in selected:
            continue
        for slot in obj.material_slots:
            principled = _find_principled(slot.material)
            if principled is None:
                continue
            for names in (("Base Color",), ("Metallic",), ("Roughness",), ("Normal",)):
                image = _linked_image(_input_value(principled, *names))
                if image is None:
                    continue
                texture_id, frame = texture_for_image(image)
                textures[texture_id] = {
                    "id": texture_id,
                    "name": image.name,
                    "mime_type": "image/png",
                    "byte_count": len(frame) - 20,
                    "frame": frame,
                }

    _last_viewport_environment = None
    shading = None
    for window in getattr(bpy.context.window_manager, "windows", []):
        for area in getattr(window.screen, "areas", []):
            if area.type == "VIEW_3D":
                shading = area.spaces.active.shading
                break
        if shading is not None:
            break
    if shading is not None and shading.type == "MATERIAL":
        studio_name = getattr(shading, "studio_light", "")
        studio = next((item for item in bpy.context.preferences.studio_lights
                       if item.name == studio_name), None)
        path = getattr(studio, "path", "") if studio else ""
        if path and os.path.exists(path):
            existing = bpy.data.images.get("Blender Viewer Material Preview")
            image = existing or bpy.data.images.load(path, check_existing=False)
            if existing is None:
                image.name = "Blender Viewer Material Preview"
            try:
                texture_id, frame = texture_for_image(image)
                textures[texture_id] = {
                    "id": texture_id,
                    "name": studio_name,
                    "mime_type": "image/png",
                    "byte_count": len(frame) - 20,
                    "frame": frame,
                }
                _last_viewport_environment = {
                    "texture": texture_id,
                    "name": studio_name,
                    "intensity": round(float(getattr(shading, "studiolight_background_alpha", 1.0) or 1.0), 4),
                    "rotation": round(float(getattr(shading, "studiolight_rotate_z", 0.0)), 5),
                }
            finally:
                if existing is None:
                    bpy.data.images.remove(image)
    return textures


def material_payload(mat):
    out = {
        "name": mat.name if mat else "Default",
        "base_color": [0.8, 0.8, 0.8, 1.0],
        "metallic": 0.0,
        "roughness": 0.5,
        "emission_color": [0.0, 0.0, 0.0],
        "emission_strength": 0.0,
        "alpha": 1.0,
        "base_color_texture": None,  # texture id, Phase 4
        "metallic_texture": None,
        "metallic_texture_channel": None,
        "roughness_texture": None,
        "roughness_texture_channel": None,
        "normal_texture": None,
        "normal_strength": 1.0,
    }
    node = _find_principled(mat)
    if node is None:
        if mat and not mat.use_nodes:
            out["base_color"] = _rounded(mat.diffuse_color)
            out["metallic"] = round(float(mat.metallic), 4)
            out["roughness"] = round(float(mat.roughness), 4)
        return out

    base = _input_value(node, "Base Color")
    image = _linked_image(base)
    if image is not None:
        texture_id = _image_texture_ids.get(image.as_pointer())
        if texture_id is None:
            texture_id, _ = texture_for_image(image)
        out["base_color_texture"] = texture_id
    elif base is not None and not base.is_linked:
        out["base_color"] = _rounded(base.default_value)
    metallic = _input_value(node, "Metallic")
    image, channel = _linked_texture(metallic)
    if image is not None:
        out["metallic_texture"] = _image_texture_ids.get(image.as_pointer())
        out["metallic_texture_channel"] = channel
    if metallic is not None and not metallic.is_linked:
        out["metallic"] = round(float(metallic.default_value), 4)
    rough = _input_value(node, "Roughness")
    image, channel = _linked_texture(rough)
    if image is not None:
        out["roughness_texture"] = _image_texture_ids.get(image.as_pointer())
        out["roughness_texture_channel"] = channel
    if rough is not None and not rough.is_linked:
        out["roughness"] = round(float(rough.default_value), 4)
    normal = _input_value(node, "Normal")
    image, _ = _linked_texture(normal)
    if image is not None:
        out["normal_texture"] = _image_texture_ids.get(image.as_pointer())
    normal_map = _linked_node(normal, "ShaderNodeNormalMap")
    if normal_map is not None:
        strength_socket = normal_map.inputs.get("Strength")
        if strength_socket is not None:
            out["normal_strength"] = round(float(strength_socket.default_value), 4)
    alpha = _input_value(node, "Alpha")
    if alpha is not None and not alpha.is_linked:
        out["alpha"] = round(float(alpha.default_value), 4)
    emission = _input_value(node, "Emission Color", "Emission")
    if emission is not None and not emission.is_linked:
        out["emission_color"] = _rounded(list(emission.default_value)[:3])
    strength = _input_value(node, "Emission Strength")
    if strength is not None and not strength.is_linked:
        out["emission_strength"] = round(float(strength.default_value), 4)
    return out


# ---------------------------------------------------------------------------
# Lights / cameras
# ---------------------------------------------------------------------------

_LIGHT_KIND = {"POINT": "point", "SUN": "sun", "SPOT": "spot", "AREA": "area"}


def light_payload(obj):
    light = obj.data
    kind = _LIGHT_KIND.get(light.type)
    if kind is None:
        return None
    out = {
        "name": obj.name,
        "kind": kind,
        # oriented: sun/spot/area aim along local -Z on both sides
        "transform": convert_matrix_oriented(obj.matrix_world),
        "color": _rounded(light.color),
        "energy": round(float(light.energy), 3),
    }
    if light.type == "SPOT":
        out["spot_angle"] = round(float(light.spot_size), 5)
        out["spot_blend"] = round(float(light.spot_blend), 5)
    elif light.type == "AREA":
        size_y = light.size_y if light.shape in {"RECTANGLE", "ELLIPSE"} else light.size
        out["area_size"] = [round(float(light.size), 5), round(float(size_y), 5)]
    return out


def camera_payload(obj, active_name):
    cam = obj.data
    sensor = cam.sensor_width if cam.sensor_fit != "VERTICAL" else cam.sensor_height
    fov_deg = math.degrees(2.0 * math.atan(sensor / (2.0 * cam.lens)))
    return {
        "name": obj.name,
        "transform": convert_matrix_oriented(obj.matrix_world),
        "lens_mm": round(float(cam.lens), 3),
        "sensor_mm": round(float(sensor), 3),
        "sensor_fit": cam.sensor_fit,
        "fov_deg": round(fov_deg, 3),
        "is_active": obj.name == active_name,
    }


def viewport_camera_payload():
    """Current 3D viewport view as a pseudo-camera named 'Viewport'."""
    wm = bpy.context.window_manager
    if wm is None:
        return None
    for window in wm.windows:
        screen = window.screen
        if screen is None:
            continue
        for area in screen.areas:
            if area.type != "VIEW_3D":
                continue
            space = area.spaces.active
            r3d = getattr(space, "region_3d", None)
            if r3d is None:
                continue
            world = r3d.view_matrix.inverted()
            fov_deg = math.degrees(2.0 * math.atan(36.0 / (2.0 * space.lens)))
            return {
                "name": "Viewport",
                "transform": convert_matrix_oriented(world),
                "lens_mm": round(float(space.lens), 3),
                "sensor_mm": 36.0,
                "sensor_fit": "AUTO",
                "fov_deg": round(fov_deg, 3),
                "is_active": False,
                "is_viewport": True,
            }
    return None


# ---------------------------------------------------------------------------
# Selection / snapshot
# ---------------------------------------------------------------------------

def selected_names():
    try:
        return sorted(o.name for o in bpy.context.selected_objects)
    except AttributeError:
        return []


def snapshot_messages(selected_only=False):
    """Yield protocol-1 messages: scene_begin, N × object_add, scene_end.

    Chunked per object so the phone can render progressively.
    """
    depsgraph = bpy.context.evaluated_depsgraph_get()
    scene = bpy.context.scene

    objects = [
        o for o in scene.objects
        if o.type in {"MESH", "LIGHT", "CAMERA"} and o.visible_get()
    ]
    if selected_only:
        sel = set(selected_names())
        objects = [
            o for o in objects
            if o.name in sel or o.type == "CAMERA"  # cameras always ride along
        ]

    meshes = [o for o in objects if o.type == "MESH"]
    lights = [o for o in objects if o.type == "LIGHT"]
    cameras = [o for o in objects if o.type == "CAMERA"]

    snapshot_id = snapshot_messages._next_id
    snapshot_messages._next_id += 1

    yield {
        "type": "scene_begin",
        "protocol": PROTOCOL_VERSION,
        "snapshot_id": snapshot_id,
        "scene": {
            "name": scene.name,
            "frame": scene.frame_current,
            "fps": scene.render.fps / scene.render.fps_base,
        },
        "object_count": len(meshes),
    }

    totals = {"vertices": 0, "triangles": 0, "materials": 0}
    material_names = set()

    for obj in meshes:
        geo = _mesh_payload(obj, depsgraph)
        if geo is None:
            continue
        materials = [
            material_payload(slot.material) for slot in obj.material_slots
        ] or [material_payload(None)]
        for m in materials:
            material_names.add(m["name"])
        totals["vertices"] += geo["stats"]["vertices"]
        totals["triangles"] += geo["stats"]["triangles"]
        dims = _rounded(obj.dimensions)
        yield {
            "type": "object_add",
            "snapshot_id": snapshot_id,
            "object": {
                "name": obj.name,
                "kind": "mesh",
                "transform": convert_matrix(obj.matrix_world),
                "dimensions": [dims[0], dims[2], dims[1]],  # swizzled extents
                "materials": materials,
                "geometry": geo,
            },
        }

    totals["materials"] = len(material_names)

    active_cam = scene.camera.name if scene.camera else None
    camera_list = [camera_payload(o, active_cam) for o in cameras]
    vp = viewport_camera_payload()
    if vp is not None:
        camera_list.append(vp)

    yield {
        "type": "scene_end",
        "snapshot_id": snapshot_id,
        "lights": [p for p in (light_payload(o) for o in lights) if p],
        "cameras": camera_list,
        "active_camera": active_cam,
        "viewport_environment": _last_viewport_environment,
        "selected": selected_names(),
        "stats": {
            "objects": len(meshes),
            "lights": len(lights),
            "cameras": len(camera_list),
            **totals,
        },
    }


snapshot_messages._next_id = 1


def transform_update_message(obj_names):
    """Lightweight delta: just transforms for the named objects.

    Meshes get the conjugated form (the iOS delta path needs it);
    cameras and lights get the oriented form (their local -Z is meaningful).
    """
    scene_objects = bpy.context.scene.objects
    items = []
    for name in obj_names:
        obj = scene_objects.get(name)
        if obj is None:
            continue
        if obj.type in {"CAMERA", "LIGHT"}:
            transform = convert_matrix_oriented(obj.matrix_world)
        else:
            transform = convert_matrix(obj.matrix_world)
        items.append({"name": name, "transform": transform})
    return {"type": "transform_update", "objects": items}
