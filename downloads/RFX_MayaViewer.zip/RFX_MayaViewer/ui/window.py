# RFX_MayaViewer - ui/window.py
# Reimagine Fx
# Author: Amar Shinde
# Website: www.reimaginefx.com

import os

import maya.OpenMayaUI as omui
from PySide6 import QtWidgets, QtCore, QtGui
from PySide6.QtCore import Qt
import shiboken6


PLUGIN_NAME = "RFX Maya Viewer"
STUDIO_NAME = "Reimagine Fx"
AUTHOR_NAME = "Amar Shinde"
WEBSITE = "https://www.reimaginefx.com"
VERSION = "1.1"
try:
    del BUILD
except NameError:
    pass
WINDOW_TITLE = "RFX Maya Viewer"
WINDOW_W = 368

ICON_FILENAME = "rfx_mayaviewer_start.png"

DESCRIPTION_1 = (
    "Maya Viewer was built by Amar Shinde at Reimagine Fx to help 3D artists "
    "inspect, present, and review Maya scenes directly from iPhone. It connects "
    "to a live Maya session, streams scene geometry, cameras, lights, materials, "
    "textures, stats, and transform controls, then brings that work into a clean "
    "mobile viewer and AR experience."
)
DESCRIPTION_2 = (
    "Every detail is designed to feel natural beside a Maya and Arnold workflow: "
    "fast scene previews, camera framing, wireframe and texture checks, "
    "selected-object viewing, snapshots, AR placement, and lightweight transform "
    "controls without pulling artists away from the desktop scene."
)

# Apple-inspired dark interface tuned to the cyan-blue icon.
C_WINDOW = "#05070a"
C_SURFACE = "#0a0f15"
C_PANEL = "#101821"
C_PANEL_SOFT = "#121d27"
C_PANEL_HI = "#182737"
C_FIELD = "#071019"
C_BORDER = "#1d3344"
C_BORDER_HI = "#2f6380"
C_ACCENT = "#63f0f4"
C_ACCENT_SOFT = "#2ed9e3"
C_ACCENT_DEEP = "#0d6573"
C_BLUE = "#277cff"
C_BLUE_DARK = "#143b7a"
C_TEXT = "#f2f7fb"
C_TEXT_SECONDARY = "#a8b7c4"
C_TEXT_MUTED = "#667683"
C_TEXT_FAINT = "#3d4b56"
C_RED = "#ff5f72"
C_RED_DARK = "#5a1f2b"
C_RED_SOFT = "#812b3a"
C_GREEN = "#47f0a7"
C_GREEN_DARK = "#0f4734"


STYLESHEET = (
    "QWidget {"
    "    background-color: " + C_WINDOW + ";"
    "    color: " + C_TEXT_SECONDARY + ";"
    "    font-family: 'SF Pro Text', 'Segoe UI', 'Helvetica Neue', Arial, sans-serif;"
    "    font-size: 12px;"
    "    letter-spacing: 0px;"
    "}"
    "QLabel { background-color: transparent; border: none; }"
    "QLineEdit {"
    "    background-color: " + C_FIELD + ";"
    "    border: 1px solid " + C_BORDER + ";"
    "    border-radius: 8px;"
    "    padding: 7px 10px;"
    "    color: " + C_TEXT + ";"
    "    selection-background-color: " + C_ACCENT_DEEP + ";"
    "}"
    "QLineEdit:focus { border-color: " + C_ACCENT_DEEP + "; }"
    "QLineEdit:disabled { color: " + C_TEXT_FAINT + "; border-color: " + C_BORDER + "; }"
    "QSpinBox {"
    "    background-color: " + C_FIELD + ";"
    "    border: 1px solid " + C_BORDER + ";"
    "    border-radius: 8px;"
    "    padding: 6px 10px;"
    "    color: " + C_TEXT + ";"
    "    font-size: 13px;"
    "}"
    "QSpinBox:focus { border-color: " + C_ACCENT_DEEP + "; }"
    "QSpinBox:disabled { color: " + C_TEXT_FAINT + "; border-color: " + C_BORDER + "; }"
    "QSpinBox::up-button, QSpinBox::down-button {"
    "    width: 18px; border: none; background: transparent;"
    "}"
    "QToolTip {"
    "    background-color: " + C_PANEL_HI + ";"
    "    border: 1px solid " + C_BORDER_HI + ";"
    "    border-radius: 6px;"
    "    color: " + C_TEXT + ";"
    "    padding: 5px 8px;"
    "}"
    "QScrollArea { background-color: transparent; border: none; }"
    "QScrollBar:vertical { width: 5px; background: transparent; margin: 2px; }"
    "QScrollBar::handle:vertical {"
    "    background: " + C_BORDER_HI + ";"
    "    border-radius: 2px; min-height: 24px;"
    "}"
    "QScrollBar::handle:vertical:hover { background: " + C_ACCENT_DEEP + "; }"
    "QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }"
    "QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical { background: none; }"
)


def _icon_path():
    """Return the absolute path to the plugin icon, or None if not found."""
    this_file = os.path.abspath(__file__)
    icons_dir = os.path.join(os.path.dirname(os.path.dirname(this_file)), "icons")
    path = os.path.join(icons_dir, ICON_FILENAME)
    return path if os.path.isfile(path) else None


def _panel_style():
    return (
        "QWidget#Panel {"
        "    background-color: " + C_PANEL + ";"
        "    border: 1px solid " + C_BORDER + ";"
        "    border-radius: 8px;"
        "}"
    )


def _section_title(text):
    lbl = QtWidgets.QLabel(text)
    lbl.setStyleSheet(
        "QLabel {"
        "    background-color: transparent;"
        "    border: none;"
        "    color: " + C_TEXT + ";"
        "    font-size: 12px;"
        "    font-weight: 700;"
        "}"
    )
    return lbl


def _caption(text):
    lbl = QtWidgets.QLabel(text)
    lbl.setWordWrap(True)
    lbl.setStyleSheet(
        "QLabel {"
        "    background-color: transparent;"
        "    border: none;"
        "    color: " + C_TEXT_MUTED + ";"
        "    font-size: 11px;"
        "    line-height: 1.35;"
        "}"
    )
    return lbl


def _value_label(text):
    lbl = QtWidgets.QLabel(text)
    lbl.setStyleSheet(
        "QLabel {"
        "    background-color: transparent;"
        "    border: none;"
        "    color: " + C_TEXT_SECONDARY + ";"
        "    font-size: 11px;"
        "    font-weight: 600;"
        "}"
    )
    return lbl


def _btn_style(bg, bg_hover, border, text_color):
    return (
        "QPushButton {"
        "    background-color: " + bg + ";"
        "    border: 1px solid " + border + ";"
        "    border-radius: 8px;"
        "    color: " + text_color + ";"
        "    font-size: 13px;"
        "    font-weight: 700;"
        "    padding: 9px 12px;"
        "}"
        "QPushButton:hover {"
        "    background-color: " + bg_hover + ";"
        "    border-color: " + C_ACCENT_DEEP + ";"
        "}"
        "QPushButton:pressed {"
        "    background-color: " + C_ACCENT_DEEP + ";"
        "}"
        "QPushButton:disabled {"
        "    background-color: " + C_SURFACE + ";"
        "    border-color: " + C_BORDER + ";"
        "    color: " + C_TEXT_FAINT + ";"
        "}"
    )


def _pill_style(bg, fg, border):
    return (
        "QLabel {"
        "    background-color: transparent;"
        "    border: none;"
        "    color: " + fg + ";"
        "    font-size: 10px;"
        "    font-weight: 700;"
        "    padding: 0 2px;"
        "}"
    )


def _make_icon_label(size):
    icon_lbl = QtWidgets.QLabel()
    icon_lbl.setStyleSheet("QLabel { background: transparent; border: none; }")
    icon_path = _icon_path()
    if icon_path:
        pix = QtGui.QPixmap(icon_path).scaled(
            size, size, Qt.KeepAspectRatio, Qt.SmoothTransformation
        )
        icon_lbl.setFixedSize(size, size)
        icon_lbl.setAlignment(Qt.AlignCenter)
        icon_lbl.setPixmap(pix)
    else:
        icon_lbl.setFixedSize(size, size)
        icon_lbl.setStyleSheet(
            "QLabel {"
            "    background-color: " + C_PANEL_HI + ";"
            "    border: 1px solid " + C_ACCENT_DEEP + ";"
            "    border-radius: 8px;"
            "}"
        )
    return icon_lbl


class AboutDialog(QtWidgets.QDialog):

    def __init__(self, parent=None):
        super(AboutDialog, self).__init__(parent)
        self.setWindowTitle("About Maya Viewer")
        self.setFixedWidth(440)
        self.setWindowFlags(self.windowFlags() & ~Qt.WindowContextHelpButtonHint)
        self.setStyleSheet(STYLESHEET)
        self._build()

    def _build(self):
        root = QtWidgets.QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        header = QtWidgets.QWidget()
        header.setObjectName("AboutHeader")
        header.setFixedHeight(132)
        header.setStyleSheet(
            "QWidget#AboutHeader {"
            "    background-color: " + C_SURFACE + ";"
            "    border-bottom: 1px solid " + C_BORDER + ";"
            "}"
        )
        header_layout = QtWidgets.QHBoxLayout(header)
        header_layout.setContentsMargins(24, 18, 24, 18)
        header_layout.setSpacing(16)
        header_layout.addWidget(_make_icon_label(64), 0, Qt.AlignVCenter)

        text_col = QtWidgets.QVBoxLayout()
        text_col.setContentsMargins(0, 0, 0, 0)
        text_col.setSpacing(4)

        title_lbl = QtWidgets.QLabel("Maya Viewer")
        title_lbl.setStyleSheet(
            "QLabel { background-color: transparent; border: none; color: " + C_TEXT + "; font-size: 24px; font-weight: 800; }"
        )
        subtitle_lbl = QtWidgets.QLabel("Live scene streaming for iPhone")
        subtitle_lbl.setStyleSheet(
            "QLabel { background-color: transparent; border: none; color: " + C_ACCENT + "; font-size: 12px; font-weight: 700; }"
        )
        studio_lbl = QtWidgets.QLabel(STUDIO_NAME)
        studio_lbl.setStyleSheet(
            "QLabel { background-color: transparent; border: none; color: " + C_TEXT_MUTED + "; font-size: 11px; }"
        )

        text_col.addStretch()
        text_col.addWidget(title_lbl)
        text_col.addWidget(subtitle_lbl)
        text_col.addWidget(studio_lbl)
        text_col.addStretch()

        header_layout.addLayout(text_col)
        header_layout.addStretch()
        root.addWidget(header)

        scroll = QtWidgets.QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scroll.setFrameShape(QtWidgets.QFrame.NoFrame)

        body = QtWidgets.QWidget()
        body.setStyleSheet("QWidget { background-color: " + C_WINDOW + "; }")
        body_layout = QtWidgets.QVBoxLayout(body)
        body_layout.setContentsMargins(22, 18, 22, 18)
        body_layout.setSpacing(14)

        for text in (DESCRIPTION_1, DESCRIPTION_2):
            lbl = QtWidgets.QLabel(text)
            lbl.setWordWrap(True)
            lbl.setStyleSheet(
                "QLabel { background-color: transparent; border: none; color: " + C_TEXT_SECONDARY + "; font-size: 12px; line-height: 1.45; }"
            )
            body_layout.addWidget(lbl)

        card = QtWidgets.QWidget()
        card.setObjectName("Panel")
        card.setStyleSheet(_panel_style())
        card_layout = QtWidgets.QVBoxLayout(card)
        card_layout.setContentsMargins(16, 12, 16, 12)
        card_layout.setSpacing(10)

        rows = [
            ("Creator", AUTHOR_NAME),
            ("Studio", STUDIO_NAME),
            ("Website", WEBSITE),
            ("Version", VERSION),
        ]
        for label, value in rows:
            row = QtWidgets.QHBoxLayout()
            row.setContentsMargins(0, 0, 0, 0)
            row.setSpacing(10)
            row.addWidget(_value_label(label))
            row.addStretch()
            val = QtWidgets.QLabel(value)
            val.setTextInteractionFlags(Qt.TextSelectableByMouse)
            val.setStyleSheet(
                "QLabel { background-color: transparent; border: none; color: " + C_TEXT + "; font-size: 12px; font-weight: 600; }"
            )
            row.addWidget(val)
            card_layout.addLayout(row)

        body_layout.addWidget(card)
        body_layout.addStretch()
        scroll.setWidget(body)
        root.addWidget(scroll)

        footer = QtWidgets.QWidget()
        footer.setFixedHeight(58)
        footer.setObjectName("AboutFooter")
        footer.setStyleSheet(
            "QWidget#AboutFooter {"
            "    background-color: " + C_SURFACE + ";"
            "    border-top: 1px solid " + C_BORDER + ";"
            "}"
        )
        footer_layout = QtWidgets.QHBoxLayout(footer)
        footer_layout.setContentsMargins(18, 0, 18, 0)
        footer_layout.addStretch()

        close_btn = QtWidgets.QPushButton("Close")
        close_btn.setFixedSize(92, 34)
        close_btn.setCursor(QtGui.QCursor(Qt.PointingHandCursor))
        close_btn.setStyleSheet(
            _btn_style(C_PANEL_SOFT, C_PANEL_HI, C_BORDER, C_TEXT_SECONDARY)
        )
        close_btn.clicked.connect(self.accept)
        footer_layout.addWidget(close_btn)
        root.addWidget(footer)

        self.setMinimumHeight(500)
        self.setMaximumHeight(640)


class MayaViewerWindow(QtWidgets.QWidget):

    def __init__(self, parent=None):
        super(MayaViewerWindow, self).__init__(parent)
        self.setObjectName("RFX_MayaViewer_Window")
        self.setFixedWidth(WINDOW_W)
        self.setStyleSheet(STYLESHEET)
        self._build_ui()
        self._refresh_status()

    def _build_ui(self):
        root = QtWidgets.QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)
        root.addWidget(self._make_header())
        root.addWidget(self._make_body())

    def _make_header(self):
        header = QtWidgets.QWidget()
        header.setObjectName("Header")
        header.setFixedHeight(154)
        header.setStyleSheet(
            "QWidget#Header {"
            "    background-color: " + C_SURFACE + ";"
            "    border-bottom: 1px solid " + C_BORDER + ";"
            "}"
        )
        layout = QtWidgets.QVBoxLayout(header)
        layout.setContentsMargins(18, 18, 18, 14)
        layout.setSpacing(12)

        top = QtWidgets.QHBoxLayout()
        top.setContentsMargins(0, 0, 0, 0)
        top.setSpacing(14)
        top.addWidget(_make_icon_label(58), 0, Qt.AlignVCenter)

        title_col = QtWidgets.QVBoxLayout()
        title_col.setContentsMargins(0, 0, 0, 0)
        title_col.setSpacing(2)

        title_lbl = QtWidgets.QLabel("Maya Viewer")
        title_lbl.setStyleSheet(
            "QLabel { background-color: transparent; border: none; color: " + C_TEXT + "; font-size: 24px; font-weight: 800; }"
        )
        studio_lbl = QtWidgets.QLabel("Reimagine Fx")
        studio_lbl.setStyleSheet(
            "QLabel { background-color: transparent; border: none; color: " + C_ACCENT + "; font-size: 11px; font-weight: 700; }"
        )

        title_col.addStretch()
        title_col.addWidget(title_lbl)
        title_col.addWidget(studio_lbl)
        title_col.addStretch()
        top.addLayout(title_col)
        top.addStretch()

        about_btn = QtWidgets.QPushButton("i")
        about_btn.setFixedSize(28, 28)
        about_btn.setCursor(QtGui.QCursor(Qt.PointingHandCursor))
        about_btn.setToolTip("About RFX Maya Viewer")
        about_btn.setStyleSheet(
            "QPushButton {"
            "    background-color: " + C_PANEL + ";"
            "    border: 1px solid " + C_BORDER + ";"
            "    border-radius: 8px;"
            "    color: " + C_ACCENT + ";"
            "    font-size: 13px;"
            "    font-weight: 800;"
            "}"
            "QPushButton:hover {"
            "    border-color: " + C_ACCENT_DEEP + ";"
            "    background-color: " + C_PANEL_HI + ";"
            "}"
        )
        about_btn.clicked.connect(self._open_about)
        top.addWidget(about_btn, 0, Qt.AlignTop)
        layout.addLayout(top)

        tagline = QtWidgets.QLabel("Private bridge from Maya to your iPhone viewer.")
        tagline.setWordWrap(True)
        tagline.setStyleSheet(
            "QLabel { background-color: transparent; border: none; color: " + C_TEXT_MUTED + "; font-size: 12px; }"
        )
        layout.addWidget(tagline)

        chips = QtWidgets.QHBoxLayout()
        chips.setSpacing(6)
        for text in ("WebSocket", "Scene", "AR"):
            chip = QtWidgets.QLabel(text)
            chip.setStyleSheet(_pill_style(C_FIELD, C_TEXT_SECONDARY, C_BORDER))
            chips.addWidget(chip)
        chips.addStretch()
        layout.addLayout(chips)

        return header

    def _make_body(self):
        body = QtWidgets.QWidget()
        body.setStyleSheet("QWidget { background-color: " + C_WINDOW + "; }")
        layout = QtWidgets.QVBoxLayout(body)
        layout.setContentsMargins(14, 14, 14, 16)
        layout.setSpacing(10)

        layout.addWidget(self._make_status_panel())
        layout.addWidget(self._make_connection_panel())
        layout.addWidget(self._make_action_panel())
        layout.addStretch()
        return body

    def _make_status_panel(self):
        panel = QtWidgets.QWidget()
        panel.setObjectName("Panel")
        panel.setStyleSheet(_panel_style())
        layout = QtWidgets.QVBoxLayout(panel)
        layout.setContentsMargins(14, 13, 14, 13)
        layout.setSpacing(8)

        row = QtWidgets.QHBoxLayout()
        row.setSpacing(10)

        self._status_dot = QtWidgets.QLabel()
        self._status_dot.setFixedSize(10, 10)
        self._status_dot.setObjectName("StatusDot")
        row.addWidget(self._status_dot, 0, Qt.AlignVCenter)

        text_col = QtWidgets.QVBoxLayout()
        text_col.setContentsMargins(0, 0, 0, 0)
        text_col.setSpacing(1)
        self._status_lbl = QtWidgets.QLabel("Server stopped")
        self._status_lbl.setStyleSheet(
            "QLabel { background-color: transparent; border: none; color: " + C_TEXT + "; font-size: 15px; font-weight: 800; }"
        )
        self._status_hint = QtWidgets.QLabel("Start the local bridge before opening the iOS app.")
        self._status_hint.setWordWrap(True)
        self._status_hint.setStyleSheet(
            "QLabel { background-color: transparent; border: none; color: " + C_TEXT_MUTED + "; font-size: 11px; }"
        )
        text_col.addWidget(self._status_lbl)
        text_col.addWidget(self._status_hint)
        row.addLayout(text_col)
        layout.addLayout(row)

        return panel

    def _make_connection_panel(self):
        panel = QtWidgets.QWidget()
        panel.setObjectName("Panel")
        panel.setStyleSheet(_panel_style())
        layout = QtWidgets.QVBoxLayout(panel)
        layout.setContentsMargins(14, 13, 14, 13)
        layout.setSpacing(10)

        layout.addWidget(_section_title("Connection"))
        layout.addWidget(_caption("Use the same network as this Maya workstation."))

        port_row = QtWidgets.QHBoxLayout()
        port_row.setContentsMargins(0, 0, 0, 0)
        port_row.setSpacing(10)
        port_row.addWidget(_value_label("Port"))

        self._port_spin = QtWidgets.QSpinBox()
        self._port_spin.setRange(1024, 65535)
        self._port_spin.setValue(9001)
        self._port_spin.setFixedHeight(34)
        self._port_spin.setToolTip("WebSocket port the iOS app will connect to")
        port_row.addWidget(self._port_spin)
        layout.addLayout(port_row)

        pin_row = QtWidgets.QHBoxLayout()
        pin_row.setContentsMargins(0, 0, 0, 0)
        pin_row.setSpacing(10)
        pin_row.addWidget(_value_label("PIN"))

        self._pin_edit = QtWidgets.QLineEdit()
        self._pin_edit.setPlaceholderText("Optional")
        self._pin_edit.setMaxLength(32)
        self._pin_edit.setFixedHeight(34)
        self._pin_edit.setToolTip("Optional connection PIN. Leave empty for no PIN.")
        pin_row.addWidget(self._pin_edit)
        layout.addLayout(pin_row)

        self._ip_panel = QtWidgets.QWidget()
        self._ip_panel.setObjectName("IpPanel")
        self._ip_panel.setStyleSheet(
            "QWidget#IpPanel { background: transparent; border: none; }"
        )
        ip_layout = QtWidgets.QVBoxLayout(self._ip_panel)
        ip_layout.setContentsMargins(0, 2, 0, 0)
        ip_layout.setSpacing(7)

        ip_layout.addWidget(_value_label("Enter one of these IPs in the iOS app"))

        self._ip_fields = []
        for _ in range(3):
            field = QtWidgets.QLineEdit()
            field.setReadOnly(True)
            field.setAlignment(Qt.AlignCenter)
            field.setFixedHeight(34)
            field.setStyleSheet(
                "QLineEdit {"
                "    background-color: " + C_FIELD + ";"
                "    border: 1px solid " + C_ACCENT_DEEP + ";"
                "    border-radius: 8px;"
                "    color: " + C_ACCENT + ";"
                "    font-size: 14px;"
                "    font-weight: 800;"
                "}"
            )
            self._ip_fields.append((field, field))
            ip_layout.addWidget(field)
            field.setVisible(False)

        self._ip_panel.setVisible(False)
        layout.addWidget(self._ip_panel)
        return panel

    def _make_action_panel(self):
        panel = QtWidgets.QWidget()
        panel.setObjectName("ActionPanel")
        panel.setStyleSheet(
            "QWidget#ActionPanel { background: transparent; border: none; }"
        )
        layout = QtWidgets.QVBoxLayout(panel)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(8)

        self._start_btn = QtWidgets.QPushButton("Start Server")
        self._start_btn.setFixedHeight(42)
        self._start_btn.setCursor(QtGui.QCursor(Qt.PointingHandCursor))
        self._start_btn.setStyleSheet(
            _btn_style(C_BLUE, C_ACCENT_DEEP, C_BLUE, C_TEXT)
        )
        self._start_btn.clicked.connect(self._on_start)
        layout.addWidget(self._start_btn)

        self._stop_btn = QtWidgets.QPushButton("Stop Server")
        self._stop_btn.setFixedHeight(40)
        self._stop_btn.setCursor(QtGui.QCursor(Qt.PointingHandCursor))
        self._stop_btn.setStyleSheet(
            _btn_style(C_PANEL_SOFT, C_PANEL_HI, C_BORDER, C_TEXT_SECONDARY)
        )
        self._stop_btn.clicked.connect(self._on_stop)
        layout.addWidget(self._stop_btn)

        return panel

    def _on_start(self):
        try:
            import rfx_mayaviewer as mv
        except Exception as e:
            QtWidgets.QMessageBox.critical(
                self, "RFX Maya Viewer",
                "Could not load rfx_mayaviewer:\n" + str(e)
            )
            return
        port = self._port_spin.value()
        self._start_btn.setEnabled(False)
        self._stop_btn.setEnabled(False)
        try:
            mv.start_server(port=port, pin=self._pin_edit.text().strip())
        except Exception as e:
            QtWidgets.QMessageBox.critical(
                self, "RFX Maya Viewer",
                "Failed to start server on port %d:\n%s" % (port, str(e))
            )
        self._refresh_status()

    def _on_stop(self):
        try:
            import rfx_mayaviewer as mv
            mv.stop_server()
        except Exception as e:
            QtWidgets.QMessageBox.critical(
                self, "RFX Maya Viewer",
                "Failed to stop server:\n" + str(e)
            )
        self._refresh_status()

    def _open_about(self):
        dlg = AboutDialog(parent=self)
        dlg.exec()

    def _set_status_dot(self, color, border):
        self._status_dot.setStyleSheet(
            "QLabel#StatusDot {"
            "    background-color: " + color + ";"
            "    border: 1px solid " + border + ";"
            "    border-radius: 5px;"
            "}"
        )

    def _refresh_status(self):
        try:
            import rfx_mayaviewer as mv
            running = bool(mv._SERVER_THREAD and mv._SERVER_THREAD.is_alive())
        except Exception:
            running = False

        if running:
            try:
                import rfx_mayaviewer as mv
                port = mv._PORT
                pin = mv._CONNECTION_PIN
            except Exception:
                port = self._port_spin.value()
                pin = self._pin_edit.text().strip()
            self._set_status_dot(C_GREEN, C_GREEN_DARK)
            self._status_lbl.setText("Server running")
            if pin:
                self._status_hint.setText("Listening on port %d with PIN protection." % port)
            else:
                self._status_hint.setText("Listening on port %d. Open the iOS app and connect." % port)
            self._start_btn.setEnabled(False)
            self._stop_btn.setStyleSheet(
                _btn_style(C_RED_DARK, C_RED_SOFT, C_RED_DARK, C_RED)
            )
            self._stop_btn.setEnabled(True)
            self._port_spin.setEnabled(False)
            self._pin_edit.setEnabled(False)
            self._show_ips(port)
        else:
            self._set_status_dot(C_TEXT_FAINT, C_BORDER)
            self._status_lbl.setText("Server stopped")
            self._status_hint.setText("Start the local bridge before opening the iOS app.")
            self._start_btn.setStyleSheet(
                _btn_style(C_BLUE, C_ACCENT_DEEP, C_BLUE, C_TEXT)
            )
            self._start_btn.setEnabled(True)
            self._stop_btn.setStyleSheet(
                _btn_style(C_PANEL_SOFT, C_PANEL_HI, C_BORDER, C_TEXT_SECONDARY)
            )
            self._stop_btn.setEnabled(False)
            self._port_spin.setEnabled(True)
            self._pin_edit.setEnabled(True)
            self._pin_edit.clear()
            self._hide_ips()

    def _show_ips(self, port):
        try:
            import rfx_mayaviewer as mv
            ips = mv._get_local_ips()
            if not ips:
                ips = ["127.0.0.1"]
        except Exception:
            ips = ["127.0.0.1"]

        self._ip_panel.setVisible(True)
        for i, (field, row_widget) in enumerate(self._ip_fields):
            if i < len(ips):
                field.setText(ips[i])
                row_widget.setVisible(True)
            else:
                row_widget.setVisible(False)

        QtCore.QTimer.singleShot(0, self.adjustSize)

    def _hide_ips(self):
        self._ip_panel.setVisible(False)
        for _, row_widget in self._ip_fields:
            row_widget.setVisible(False)
        QtCore.QTimer.singleShot(0, self.adjustSize)


_window_instance = None


def _get_maya_main_window():
    ptr = omui.MQtUtil.mainWindow()
    if ptr:
        return shiboken6.wrapInstance(int(ptr), QtWidgets.QWidget)
    return None


def launch():
    """Open the Maya Viewer control panel. Safe to call multiple times."""
    global _window_instance

    if _window_instance is not None:
        try:
            if _window_instance.isVisible():
                _window_instance._refresh_status()
                _window_instance.raise_()
                _window_instance.activateWindow()
                return _window_instance
            _window_instance.deleteLater()
        except RuntimeError:
            pass
        _window_instance = None

    parent = _get_maya_main_window()
    win = MayaViewerWindow(parent=parent)
    win.setWindowFlags(win.windowFlags() | Qt.Tool)
    win.setWindowTitle(WINDOW_TITLE)
    win.show()
    win.raise_()
    win.activateWindow()

    _window_instance = win
    return win
