# Scene scanning. Finds polygon mesh transforms by selection or visibility.

from maya import cmds


def get_mesh_shape(transform):
    if not cmds.objExists(transform):
        return None
    shapes = cmds.listRelatives(transform, shapes=True, fullPath=True, type="mesh") or []
    for shape in shapes:
        try:
            if cmds.getAttr("{0}.intermediateObject".format(shape)):
                continue
        except Exception:
            pass
        return shape
    return None


def is_valid_polygon_mesh(transform):
    shape = get_mesh_shape(transform)
    if not shape:
        return False
    try:
        verts = cmds.polyEvaluate(shape, vertex=True)
        faces = cmds.polyEvaluate(shape, face=True)
    except Exception:
        return False
    return bool(verts) and bool(faces)


def _expand_to_mesh_transforms(nodes):
    result = []
    seen = set()
    for node in nodes or []:
        try:
            if not cmds.objExists(node):
                continue
            otype = cmds.objectType(node)
        except Exception:
            continue
        if otype == "mesh":
            candidates = cmds.listRelatives(node, parent=True, fullPath=True) or []
        else:
            candidates = [node]
            descendants = cmds.listRelatives(
                node, allDescendents=True, fullPath=True, type="mesh"
            ) or []
            for shape in descendants:
                parents = cmds.listRelatives(
                    shape, parent=True, fullPath=True
                ) or []
                candidates.extend(parents)
        for cand in candidates:
            try:
                full = cmds.ls(cand, long=True) or []
            except Exception:
                full = []
            for fpath in full:
                if fpath in seen:
                    continue
                if is_valid_polygon_mesh(fpath):
                    seen.add(fpath)
                    result.append(fpath)
    return result


def get_selected_mesh_transforms():
    sel = cmds.ls(selection=True, long=True) or []
    return _expand_to_mesh_transforms(sel)


def _is_visible(dag_path):
    if not cmds.objExists(dag_path):
        return False
    try:
        if not cmds.getAttr("{0}.visibility".format(dag_path)):
            return False
    except Exception:
        return False
    parents = cmds.listRelatives(dag_path, parent=True, fullPath=True) or []
    for parent in parents:
        if not _is_visible(parent):
            return False
    return True


def get_visible_mesh_transforms():
    all_meshes = cmds.ls(type="mesh", long=True, noIntermediate=True) or []
    transforms = []
    seen = set()
    for shape in all_meshes:
        parents = cmds.listRelatives(shape, parent=True, fullPath=True) or []
        for parent in parents:
            if parent in seen:
                continue
            if not _is_visible(parent):
                continue
            if is_valid_polygon_mesh(parent):
                seen.add(parent)
                transforms.append(parent)
    return transforms


def get_all_ancestors(transform):
    # Returns the chain from world to transform (excluding transform itself).
    chain = []
    cur = transform
    while True:
        parents = cmds.listRelatives(cur, parent=True, fullPath=True) or []
        if not parents:
            break
        cur = parents[0]
        chain.insert(0, cur)
    return chain
