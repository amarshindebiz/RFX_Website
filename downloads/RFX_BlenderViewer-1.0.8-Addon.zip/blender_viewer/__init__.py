# SPDX-License-Identifier: GPL-3.0-or-later
"""
Blender Viewer — view your live Blender scene on iPhone and in AR.
Reimagine Fx | reimaginefx.com

Dual-packaged: legacy add-on (bl_info, Blender 4.5 LTS) and extension
(blender_manifest.toml, Blender 4.2+/5.x). Zero external dependencies.

Console API:
    import blender_viewer as bv
    bv.start_server(port=9010)
    bv.stop_server()
    bv.send_snapshot()
"""

bl_info = {
    "name": "Blender Viewer",
    "author": "Amar Shinde (Reimagine Fx)",
    "version": (1, 0, 8),
    "blender": (4, 2, 0),
    "location": "3D Viewport > Sidebar (N) > Blender Viewer",
    "description": "Stream the live scene to the Blender Viewer iPhone app "
                   "over local WiFi (view + AR)",
    "doc_url": "https://reimaginefx.com",
    "category": "3D View",
}

import bpy

from . import commands, handlers, ui_panel
from .server import main_thread_queue

_PUMP_INTERVAL = 0.05
_MAX_TASKS_PER_PUMP = 8


def _pump_main_thread_queue():
    """Drain socket-thread work onto the main thread. The ONLY place
    incoming network messages are allowed to touch bpy."""
    processed = 0
    while processed < _MAX_TASKS_PER_PUMP and not main_thread_queue.empty():
        try:
            fn = main_thread_queue.get_nowait()
        except Exception:
            break
        try:
            fn()
        except Exception as exc:
            print(f"[Blender Viewer] command failed: {exc!r}")
        processed += 1
    return _PUMP_INTERVAL


# --- console API -------------------------------------------------------------

def start_server(port=commands.DEFAULT_PORT):
    return commands.start_server(port=port)


def stop_server():
    commands.stop_server()


def send_snapshot():
    commands.send_snapshot()


def server_running():
    return commands.server_running()


# --- registration -------------------------------------------------------------

def register():
    ui_panel.register()
    handlers.register()
    if not bpy.app.timers.is_registered(_pump_main_thread_queue):
        bpy.app.timers.register(
            _pump_main_thread_queue, first_interval=_PUMP_INTERVAL,
            persistent=True,
        )


def unregister():
    commands.stop_server()
    if bpy.app.timers.is_registered(_pump_main_thread_queue):
        bpy.app.timers.unregister(_pump_main_thread_queue)
    handlers.unregister()
    ui_panel.unregister()
    while not main_thread_queue.empty():
        try:
            main_thread_queue.get_nowait()
        except Exception:
            break
